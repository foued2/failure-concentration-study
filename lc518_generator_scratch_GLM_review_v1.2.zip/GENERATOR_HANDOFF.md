# LC518 C9 generator and execution-protocol review handoff

**Status:** scratch-only implementation and protocol draft for independent read-only review. Not a final execution protocol. Not authorized for bank generation.

**Design of record:** C9 revision 2.6, commit `511bc2099ecff74b4f850b169ceef7f853c334a0`.

**C9 source:** `lc518-150/review-v1.2/analysis-revision-2026-11-02/C9_GENERATION_SPEC_REVIEW.md`  
**C9 SHA-256:** `f291ae879ef6e046c6715bb0e6a84cd5a3f5e69f07ace09e213db9b84d8b87fe`

## Summary

GLM's independent review of Claude's execution-protocol draft v1 identified six major concerns (M-1 through M-6) and ten minor/editorial notes (E-1 through E-10). The scratch implementation and protocol draft have been revised to address those points. The resulting artificial acceptance suite passes **51/51 tests** on CPython 3.13.5.

The review found and corrected one additional launcher defect: dynamic import of the generator failed because the module was not registered in `sys.modules` before its dataclass declarations executed. A regression test now covers that path.

No LC518 diagnostic or held-out bank was generated. No study bank or oracle-output package was produced. No solver body was constructed, imported or executed. No private annex was accessed. No predictive model or power study was run. No repository file was edited, committed, pushed or merged.

## Files in this package

- `lc518_generator.py`: fail-closed C9 production-generator candidate.
- `lc518_launcher.py`: fail-closed execution launcher and post-run audit candidate.
- `test_lc518_generator.py`: generator and publication-gate artificial tests.
- `test_lc518_launcher.py`: launcher, log parsing, manifest, crosswalk and audit tests.
- `EXECUTION_PROTOCOL_DRAFT_V1.2.md`: corrected execution protocol draft.
- `execution_protocol_v1.json`: structured incomplete protocol companion.
- `fixture_reproducibility.json`: two identical disposable item-8 fixture runs and their seven file digests.
- `TEST_RESULTS.txt`: latest complete test and refusal-check log.
- `SHA256SUMS`: package-file hashes.

## GLM major findings addressed

### M-1: pair metadata schema

Confirmed by direct source inspection: the C9 serialized record schema has no top-level `pair_id` or `ordering`. Both fields occur only inside hashed `rule_params`. The generator now emits no top-level duplicates. Its serialized-record validator checks D6/H6 metadata in `rule_params`, adjacency, original-before-permutation order, pair sequence, consecutive global input IDs, equal amount, equal sorted coin sets, different as-given arrays, shared top-level `canonical_id`, and identical pair-level `int32_guard`. It rejects undeclared top-level pair fields and undeclared keys in pair `rule_params`. The exact C9 record-hash payload is unchanged.

Tests cover both D6 and H6 schema behavior, wrong/missing metadata, pair order drift, nonadjacency, identity permutations, top-level field injection, and record-hash validation.

### M-2: generator environment-variable restriction

The generator does not read environment variables, command-line arguments or configuration files. Its proposed interpreter check is the hardcoded version triple `(3, 13, 5)`. The launcher verifies the complete interpreter identity and starts the exact resolved executable. `PYTHONHASHSEED=0` is set by the launcher for the child, not read by the generator.

### M-3: generator publication

The launcher publishes the byte-identical generator at `RUN_ROOT/lc518_generator.py`, adjacent to the `RUN_ROOT/bank/` output package, before invoking it. It verifies the copy before and after the run. It does not add the script to C9 item 8's six-artifact list. The launcher, two test suites and protocol JSON are also copied into the run root for audit.

### M-4: repeated-use predicate accounting

For each accepted H1-H4 record, exactly one `PREDICATE_LOG` JSON line is emitted after the record is appended to the in-memory held-out bank, with `flush=True`. Rejected candidates emit no predicate line. Each event includes `input_id`, `stratum`, `amount`, original-order `coins`, `oracle_answer`, `N0` and `repeated_use_predicate`. The launcher enforces 40 unique IDs with stratum counts 12/12/8/8 and cross-checks the events against the held-out bank and oracle attachment on item-8 PASS. Partial counts are recorded for interrupted/aborted runs; an item-8 FAIL is still a completed generation and requires all 40 records.

### M-5: closed vocabulary and stop conditions

The generator uses C9's `CROSS_BANK_COLLISION` reason for a fatal held-out-versus-fixed-D5 collision and logs it before aborting. No invented `FatalCrossBankContradiction` reason code remains. The protocol's stop conditions include fixed-key/preflight defects and item-8 FAIL. Overall acceptance requires item-8 PASS, successful predicate reconciliation, pair validation/recheck, reconciled rejection events, verified hashes, and process exit status zero.

### M-6: item-8 FAIL output semantics

The protocol now states that item-8 FAIL creates `OUTPUT_DIR` only through the final atomic rename and contains the two rejection sidecars plus the FAIL report. It contains no bank files or oracle-output attachments. A pre-rename abort leaves the final output directory absent; orphan staging is retained and hashed.

## GLM minor notes addressed

- Structured stderr events have stable `PREDICATE_LOG`, `REJECTION_EVENT` and `PAIR_VALIDATION` prefixes.
- The manifest records protocol/C9 identity, generator and launcher identities, full argv, seeds, test-suite hashes/count, interpreter fingerprint, `PYTHONHASHSEED`, stdout/stderr hashes, predicate partial counts, pair status, item-8 status, report/artifact hashes and orphan staging file hashes.
- `PYTHONHASHSEED=0` is pinned by the launcher.
- Both stdout and stderr are captured.
- The suite source hashes and passing count are pinned.
- The protocol file's own SHA-256 is external to the protocol file (to avoid a self-reference), pinned in the launcher and named in the owner GO.
- stdout/stderr files are created exclusively before setup/publication actions, so setup failures leave hashable logs and an initial manifest.
- Predicate logging remains limited to H1-H4, exactly as C9 requires.
- The 3.13.5 choice is explicitly a convention, not a correctness claim.

## Additional launcher defect fixed

The launcher's dynamic module loader originally called `exec_module()` before registering the module in `sys.modules`. CPython's `dataclasses` decorator then failed to resolve the module namespace. The loader now registers the module before execution and removes a partial registration on import failure. `test_published_generator_module_loader_handles_dataclasses` covers the corrected path.

## Latest test result

Command:

```text
python3 -m unittest -v test_lc518_generator test_lc518_launcher
```

Interpreter: CPython 3.13.5.  
Result: **51 tests passed**.  
The synthetic item-8 fixture was run twice in separate temporary directories; all seven output file digests and the report were byte-identical.

The generator and launcher entry points were separately invoked only to confirm their refusal behavior while configuration is unset. The generator refuses because `OUTPUT_DIR` is not pinned. The launcher refuses because the target interpreter/path/protocol pins are incomplete and bank-generation authorization is false. Neither invocation generated study data.

## Current hashes

| File | SHA-256 |
|---|---|
| `lc518_generator.py` | `6e4281b4bfd79783b53d93e132a538dc3d120177405e44012081c6db083c0e2f` |
| `lc518_launcher.py` | `c23115b54061cdd490e0d6f87e31e5a067d4ab99d5c4677de19e92ce64eb24a2` |
| `test_lc518_generator.py` | `d6a322bc9c28a9c5537f89a1bb6395bf52a44f79293c07b4f526ad985dfcdf64` |
| `test_lc518_launcher.py` | `febd27e1fd98ed9d27d6e802e50704fa278b504ba2d6555bbab81d0c091953b0` |
| `EXECUTION_PROTOCOL_DRAFT_V1.2.md` | `03f8415e6fc1f71164fb33c8dde2beb3286369510707a3c53d08e4ce3389c4cc` |
| `execution_protocol_v1.json` | `8e2a2913f49f838465885f708cd111bea1c83027c579c9d37157d8c3f9ba65ad` |

The launcher embeds the generator and test-suite pins. Its own digest is calculated by the launcher at run time and written to the manifest.

## Still open before protocol v1 final

1. The exact target interpreter fingerprint is not yet available: full `sys.version`, `platform.platform()`, absolute `sys.executable` and interpreter-binary SHA-256.
2. The owner must provide or ratify an absolute run root outside the repository. `OUTPUT_DIR` will be exactly `RUN_ROOT/bank` and must be hardcoded into the final generator.
3. The current generator hash is a **locked, unconfigured review-build hash**, not the final run hash. Pinning `OUTPUT_DIR` changes it. The separate bank-generation GO later changes `BANK_GENERATION_AUTHORIZED` from false to true, changing the hash again. Draft §13 therefore requires a deterministic two-state hash chain: configured-but-locked generator SHA and authorized execution generator SHA, with the exact one-literal activation diff named in the bank-generation GO. This remains open for Claude/GLM review and must not be silently changed after GO.
4. The final protocol file SHA-256 must be calculated only after all target-specific values and both generator hashes are filled. The digest is external to the protocol file and must be embedded in the launcher and named in the owner's separate GO.
5. Bank-generation authorization remains false. No bank generation is authorized by this handoff.

## Authority boundary

This package is for Claude and GLM read-only review. It does not authorize bank generation, solver construction or execution, private-annex access, predictive fitting, power analysis, repository publication or merge to `master`. No repository write or external push has occurred during this work.
