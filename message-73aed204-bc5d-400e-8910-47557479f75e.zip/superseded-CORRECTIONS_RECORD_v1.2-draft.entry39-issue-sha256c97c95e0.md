# CORRECTIONS_RECORD_v1.2-draft.md — LC518 150-Body Construction Study

**Study package:** lc518-150
**Version:** 1.2-draft (single unambiguous identifier; supersession chain in the Changelog)
**Prepared by:** GLM
**Date:** 2026-11-01
**Supersedes:** v1.1.1-draft (the text GPT reviewed this round); v1.1-draft preserved by hash in the Changelog per GPT's document-control requirement.
**Authorization scope (owner, 2026-11-01):** preparation of a corrected specification ONLY. This record does NOT authorize generating the 150 solver bodies, executing anything, or pushing any commit. GPT's review closing line is adopted verbatim as binding: *"Status remains unchanged: v1.0 frozen, correction record not yet accepted, 0/150 solver bodies, no execution, no commit and no push. This review does not expand the authorization."*
**Status of v1.0 documents:** UNCHANGED and UNTOUCHED. Byte-identical to pushed commit `3e9a29c9652a6ab4f6bab0919e386757280b2654`:
- `PARENT_DESIGN.md` sha256 `c6138342af84fe02a64390c2f6a7f4077f0268aa875ad90ee534c76a725f3437`
- `BANK_DESIGN.md` sha256 `da7f8c1ae3c5e3a582c38d91be2463061bce2acb0a772fac72d34459f4b17843`
- `ANALYSIS_SPEC.md` sha256 `fb24910cc7712c7e9e27753084ad3683d1fd422a20d875b0b5a4ca33a55f4e78`

**Review-chain status (2026-11-01 ~15:15 UTC):** GPT review of the v1.1.1 text received — C2, C4, C7 accepted; C5, C6 accepted in principle (addenda demanded); C1 and C3 revision REQUIRED (two mathematical errors found in the corrections themselves); C9 reproducibility protocol demanded; document-control fix demanded; C8 open (owner decides). This v1.2-draft is the response. **NOT YET ACCEPTED.** Agreed sequence continues: Claude challenges these exact changes → GPT re-reviews → owner decides E3 → only then construction (still gated on the private annex, work order :45/:47).

---

## 0. What changed in v1.2-draft (reviewer-driven)

| GPT finding | Where addressed |
|---|---|
| C1 two-pointer runs in the wrong direction; complexity over-collapsed; amount-zero memo states unaccounted | C1, Precomputation / Complexity / Boundary conditions and memo discipline |
| C3 extremal examples arithmetically wrong; aggregate bounds on the wrong scale (missing 1/80); single-contrast bounds missing | C3, View 2 (rewritten as a general contrast-bounds mechanism) |
| C9 draw order contradicts D1's `c_min` dependency; stratum quotas unpinned; "single RNG stream" wording conflicts with v1.0 :65–66; canonical JSON underspecified | C9, items 2–5 (per-stratum procedures, RNG protocol, serialization) |
| Header vs changelog version mismatch | Header (single identifier `1.2-draft`) + Changelog |
| C4/C5: zero-variance standardization must map constant columns to 0 | C4/C5 addendum |
| C6: count vs denominator must be explicit; rate descriptive and undefined at zero denominator | C6 addendum |

**GLM's own additional tightenings (disclosed for Claude's challenge; not demanded by GPT):** (a) the C1 memo-state count `min(n, A) + 1` silently relied on **distinct denominations** — the premise is now explicit, cited to BANK_DESIGN :29, with the degraded bound stated for the duplicate case; (b) the C1 memo discipline is pinned as an implementation ORDER (boundary check → compaction → memo lookup → memo store), which is what makes the state count provable; (c) C3's complete-case estimate normalization was ambiguous in v1.1 ("computed on C(g) only") — now pinned as the C(g)-conditional mean, explicitly separated from the 1/80-scale full-bank bounds; (d) C9 pins the `int32_guard` log field and reconciles it with the :67–69 field list; (e) C9 pins "no degenerate randrange calls" (all range widths ≥ 2).

---

## C1 — G22 algorithm description incoherent (PARENT_DESIGN §3.3 :170, §4 :271) — REVISED in v1.2

**v1.0 text (:170):**
> `| G22 | K3-bisect-prune: coins sorted ascending; at each call, bisect_left advances i past all coins > a (skip-run compaction); dict memo | Adds search-based pruning; reduces effective branching |`

**Defect.** In an ascending suffix recursion over `coins[i:]`, coins `> a` occupy the TAIL of the suffix. `bisect_left(coins, a+1) = j` bounds the usable PREFIX `[0, j)`; "advancing i past all coins > a" would advance `i` over the smallest coins and retain the oversized tail — the opposite of the stated purpose. Confirmed independently by GPT, Claude, and GLM.

**Amendment history (owned).** v1.1's replacement specified `u(a)` correctly but gave a two-pointer precomputation that iterates amounts in ASCENDING order with a forward-only pointer. For descending coins, `u(a)` is non-increasing in `a` (as the amount grows, the first usable index moves LEFT), so a forward-only pointer cannot track it: on `c = [5, 3, 1]`, A = 5, the v1.1 loop returns `u(a) = 2` for **every** a — reporting `u(5) = 2` and skipping the denominations 5 and 3 entirely, which would make G22 return incorrect answers. Found by GPT (his counterexample table adopted verbatim); defect reproduced by GLM's verification script (worklog entry 39 receipt). The bisect derivation and the compaction lemma were never affected — GPT: "The issue is specifically the two-pointer pseudocode, not the definition of u(a) or the compaction lemma."

**Replacement text (exact, for §3.3 parent table and expanded in a new §3.3.1):**

> **G22 — K3-desc-firstusable-prune.** Coins sorted **descending** `c_1 ≥ c_2 ≥ … ≥ c_n` (0-indexed `c[0] ≥ … ≥ c[n−1]`). Suffix recursion as in family K3: `f(i, a) = f(i+1, a) + (a ≥ c_i ? f(i, a − c_i) : 0)`, `f(i, 0) = 1`, `f(n, a>0) = 0`, dict memo. Before any transition at a state `(i, a)` with `a > 0`, the index is compacted to `i' = max(i, u(a))`, where `u(a)` is the **precomputed first usable index**: `u(a) = min{ i : c_i ≤ a }`, `u(a) = n` if none. `f(i, a) = f(i', a)`; recursion proceeds from `i'` only.
>
> **Precomputation (CORRECTED in v1.2 — descending amounts).** With `A ≥ 1`: sort descending, O(n log n); then fill the table by two pointers iterating amounts in DESCENDING order, so that the required `u(a)` values are non-decreasing along the iteration and a single forward-moving pointer suffices:
> ```
> u = [n] * (A + 1)            # sentinel; u[0] stays n and is never read
> j = 0
> for a in range(A, 0, -1):    # A, A−1, …, 1 — DESCENDING
>     while j < n and c[j] > a:
>         j += 1               # advances at most n times over the whole loop
>     u[a] = j
> ```
> Correctness of the sweep: for `a > a'` (both ≥ 1), `{ i : c_i ≤ a' } ⊆ { i : c_i ≤ a }`, hence `u(a) ≤ u(a')`; iterating `a` from `A` down to `1` therefore demands non-decreasing `u` values, which the monotone pointer delivers. Cost O(n + A) for the sweep. **Worked example (GPT's, independently re-verified):** `c = [5, 3, 1]`, `A = 5`:
>
> | amount a | 1 | 2 | 3 | 4 | 5 |
> |---|---|---|---|---|---|
> | u(a) | 2 | 2 | 1 | 1 | 0 |
>
> Equivalent one-shot derivation (unchanged, verified equivalent to the sweep over 3,000 randomized trials including duplicate-coin cases — worklog entry 39): with `d = (−c_0, …, −c_{n−1})` ascending, `u(a) = bisect_left(d, −a)` for `a ≥ 1` (yielding `n` exactly when no coin is ≤ a).
>
> **Compaction lemma (unchanged from v1.1; GPT: coherent).** For `a > 0` and `i ≤ u(a)`: `f(i, a) = f(u(a), a)`. Proof: descending order gives `c_j > a` for all `j < u(a)` (else `u(a)` smaller). At any such `j`, the use branch requires `a ≥ c_j` — false — so `f(j, a) = f(j+1, a)` (skip only). Chaining over `j = i, …, u(a)−1` gives the claim. Since the use branch strictly decreases `a`, every deeper state `(i'', a'')` reachable from `(u(a), a)` has `a'' ≤ a`, hence `c_j > a ≥ a''` for `j < u(a)` remains dead at all deeper states: no usable coin is ever skipped. ∎ (Termination measure `a + (n−i)(A+1)` strictly decreases along both transitions, compaction included.)
>
> **Boundary conditions and memo discipline (CLARIFIED in v1.2).** `A = 0` → return 1 immediately (the empty multiset; no sort, no table, no recursion). Otherwise, evaluation of a state `(i, a)` follows this pinned ORDER: (1) if `a = 0`, return 1 — amount-zero states are terminal and are **never memoized** (no memo write, no memo read); (2) compact `i ← max(i, u(a))` (compaction is defined only for `a > 0`; `u[0]` is never read); (3) memo lookup on `(i, a)`; (4) compute and store. `f(n, a>0) = 0` (suffix exhausted, amount unmet).
>
> **Memo-state count (CORRECTED in v1.2, with an explicit premise).** By the pinned order, every memoized key `(i, a)` has `a ≥ 1`; and whenever `i < n`, compaction guarantees `i ≥ u(a)`, hence `c_i ≤ a ≤ A`, i.e. `i ∈ { j : c_j ≤ A } ∪ { n }`. **Premise (now explicit):** the bank guarantees *coins distinct, ∈ [1, 5000]* (BANK_DESIGN §1 :29). Distinct positive integers all ≤ A are at most `min(n, A)` in number, so distinct memo index values ≤ `min(n, A) + 1` and memoized states ≤ `(min(n, A) + 1) · A ⊆ O(nA)`. Amount-zero states contribute nothing (never memoized — this closes GPT's accounting condition). Without distinctness the sharper count fails (adversarial: 40 copies of coin 1 with `A = 1` give 40 coins ≤ 1 > min(n, A) = 1 — demonstrated in the entry-39 receipt) and the bound degrades gracefully to `(n + 1) · A ⊆ O(nA)`; the algorithm's correctness never used distinctness, so G22 is valid for arbitrary positive denominations either way.
>
> **Recursion depth (unchanged from v1.1.1).** G22 remains a top-down recursive algorithm — no explicit stack — so it inherits the family K3 mandate (§3.3 :153–158) in full: `sys.setrecursionlimit(depth_bound + 200)` with `depth_bound = n + ⌊A/c_min⌋ + 1 ≤ 5301`, derivation recorded in the source header. Compaction shortens skip chains and reduces realized depth, but the declared worst-case bound is unchanged and the limit mandate is not waived by the pruning.
>
> **Complexity (CORRECTED in v1.2 — no collapse).** Sorting O(n log n); sweep O(n + A); DP O((min(n, A) + 1) · A) states × O(1) per state (compaction is a table lookup). Total time: **O(n log n + nA + A)** — stated without collapsing to O(nA), since for independently chosen n and A (in particular A = O(1)) the n log n term dominates nA (GPT's correction adopted). `A = 0` is O(1) by the immediate return. Space: memo ≤ `(min(n, A) + 1) · A` entries (dict) + O(n + A) for the sorted array and table + O(depth) stack, depth ≤ 5301. The per-state-bisect alternative O(nA log n) (GPT's original objection) remains avoided by the O(A)-sweep precomputation.
>
> **Near-duplicate disclosure (unchanged from v1.1.1; GPT: coherent).** PRINCIPAL affinity: **G20** (descending-order suffix recursion, largest-part-first reading, lru_cache) — the corrected G22 is an optimization of the G20 approach, the threshold precomputation `u(a)` being a data-structural accelerator for exactly G20's traversal; same family K3. SECONDARY affinity (separate explanation, as GPT requires): **G17** shares only the sparse dict memo carrier; it differs in sort normalization (given order vs descending), branch mechanics (skip-first vs compacted use/skip), and has no compaction. The v1.0 text's apparent affinity to **G21** was an artifact of the defective description and lapses with this correction.

Also apply to §4 roster (:271): `| 22 | G22 | K3 | descending coins, precomputed first-usable-index compaction, dict memo |`

**Justification.** GPT's reversed-iteration remedy adopted verbatim; his [5,3,1] counterexample is now a pinned worked example; his complexity-expression and terminal-state conditions adopted; the distinctness premise (GLM) is added because the state-count lemma is FALSE without it — disclosed rather than left implicit, so Claude can attack it directly.

---

## C2 — K5 final-step complexity and risk ranking (PARENT_DESIGN §3 table :64, §3.5 :236–239) — ACCEPTED by GPT, unchanged

**v1.0 text (:236–239):**
> `**Complexity.** O(nA) for both half-products plus O((A+1)²) ≈ 2.5 × 10⁷ operations for the final Cauchy product at A = 5000. **Designed performance risk:** the quadratic final convolution is the single heaviest step in the population; recorded per contract line 55 discipline as a designed risk, never as an observed timeout.`

**Defect.** The formulation (:227) computes only the target coefficient `W(A,S) = Σ_{t=0}^{A} P_L[t]·P_R[A−t]` — one dot product of two length-(A+1) arrays. Cost O(A) ≈ 5 × 10³, not O(A²) ≈ 2.5 × 10⁷. Confirmed by GPT and Claude; GLM concurs (own error).

**Replacement text (exact, unchanged from v1.1):**
> `**Complexity.** O(nA) for both half-products plus O(A) ≈ 5 × 10³ operations for the final coefficient (one dot product Σ_{t=0}^{A} P_L[t]·P_R[A−t]; the full convolution array is never formed). **Designed performance risk:** none material; the K5 parents are among the lightest in the population. The heaviest declared workload in the population is the K4 doubling schedule, O(n · A · log2(A / c_min)) ≈ 2 × 10⁷ cell operations (§3.4), which therefore carries the population's principal designed performance risk, recorded per contract line 55 discipline, never as an observed timeout.`

Also apply to the §3 family table (:64): change `O(nA + A²)` to `O(nA + A)`.

**Justification.** Algebra per GPT; consequence per GPT §1: K4-doubling becomes the computationally demanding formulation. No correctness claim changes. **GPT review status: accepted ("The final coefficient is a dot product, O(A).").**

---

## C3 — E1 matched contrasts: two-view reporting with pattern-enumerated bounds (ANALYSIS_SPEC §3 :48–72) — REVISED in v1.2

**v1.0 text (:51–54):**
> `All five versions of a parent use identical held-out records, identical oracle outputs, and identical execution conditions (work order §9). Because unresolved records are neither pass nor fail, L is reported on the resolved subset with coverage, together with worst/best bounds over unresolved records (worst: all unresolved are FAIL; best: all are PASS). No unresolved record is silently counted either way.`

**Defect.** "Reported on the resolved subset" implies per-version denominators; resolved subsets can differ across versions, so contrasts are not strictly matched. The per-input interaction (:65–68) is undefined where any of the four versions is unresolved, with no aggregation rule. Confirmed by GPT; adopted.

**Amendment history (owned).** v1.1.1's View 2 stated the correct range `i ∈ {−2,…,2}` but (i) gave extremal PATTERNS that do not attain the extremes — "max 2 = SAB fails, S0/SA/SB pass" computes `1 − 0 − 0 + 0 = +1`, and the mirrored minimum pattern computes −1 (found by GPT; owned — the error was in the draft's explanatory examples however sourced); (ii) wrote the aggregate bounds as raw sums `I_min = Σ_x min i(x)` although every aggregate contrast is a MEAN over 80 records, putting the bounds on the wrong scale; and (iii) gave bounds only for the four-version interaction, leaving the three single contrasts without full-bank bounds. All three are corrected below.

**Replacement text (exact, replaces :51–54 and extends :63–72):**

> All five versions of a parent use identical held-out records, identical oracle outputs, and identical execution conditions (work order §9). Unresolved records are never counted as pass or fail. Two pre-declared reporting views are used; neither is constructed after seeing outcomes. Notation: `loss(g, v, x) = 1[status(g, v, x) = FAIL]` for resolved outcomes, undefined for unresolved ones (:65–67); `L(g, v) = mean over the 80 held-out records of loss(g, v, x)` (:48).
>
> **View 1 — complete-case matched estimates.** For each contrast, let `C(g)` be the set of held-out records resolved by **every version entering that contrast** — explicitly: the 2 versions {S0, SA} for the A-only contrast, {S0, SB} for B-only, {S0, S-extra} for S-extra, and the 4 versions {S0, SA, SB, SAB} for the pair/interaction contrast. **This contrast-specific complete-case definition is stated as the PRIMARY convention (GPT's explicitness demand): it is per-contrast, NOT "resolved under all five versions"; the all-five convention `C₅(g) = ∩ of all five versions' resolved sets` is also computed and reported descriptively, with `|C₅(g)|/80` beside it; both coverages appear in every table so the two conventions are never confused.** Per version, `L(g, v)` is additionally reported descriptively as the resolved-subset rate with its own coverage — descriptive only, never contrasted against a different version's denominator. **Normalization (pinned in v1.2):** the matched complete-case estimate of a contrast is the C(g)-conditional mean `(1/|C(g)|) · Σ_{x ∈ C(g)} c(x)` and is always labeled as conditional on resolution; it is never mixed with, or compared against, the full-bank bounds of View 2, which are on the 1/80 full-bank scale.
>
> **View 2 — full-bank bounds with unresolved retained as unknown (REWRITTEN in v1.2).** Every E1 contrast is, per record, a fixed linear combination of the entering versions' losses: a **single contrast** `Δ(g) ∈ {Δ_A, Δ_B, Δ_S-extra}` has per-record value `d(x) = loss(g, v₁, x) − loss(g, v₀, x)` (weights +1 on the patched version, −1 on S0); the **pair/interaction contrast** has per-record value `i(g, A, B, x) = loss(g, SAB, x) − loss(g, SA, x) − loss(g, SB, x) + loss(g, S0, x)`.
>
> Per-record ranges (correct and unchanged): `d(x) ∈ {−1, 0, 1}`; `i(x) ∈ {−2, −1, 0, 1, 2}`. **Corrected extremal patterns** — written as losses in the fixed order `(S0, SA, SB, SAB)`:
>
> | Extreme | Losses (S0, SA, SB, SAB) | Computation | Reading |
> |---|---|---|---|
> | Maximum +2 | (1, 0, 0, 1) | 1 − 0 − 0 + 1 = +2 | S0 FAILS; both single patches PASS; the combined patch FAILS — each patch alone repairs the base failure, their combination does not |
> | Minimum −2 | (0, 1, 1, 0) | 0 − 1 − 1 + 0 = −2 | S0 PASSES; both single patches FAIL; the combined patch PASSES — each patch alone breaks a passing base, their combination does not |
>
> Each extreme is attained by exactly this one pattern (all 16 loss patterns enumerated in the entry-39 receipt; unique argmax/argmin). The v1.1.1 examples (SAB fails with the other three passing, and the mirror) give +1 and −1 and are withdrawn.
>
> Unresolved handling: for a record where `k` of the contrast's versions are unresolved (`k` is the **PER-INPUT** count within the contrast's version set: `k ≤ 2` for singles → at most 2² = 4 completions; `k ≤ 4` for the interaction → at most 2⁴ = 16 completions; GPT's clarification retained), the record's contrast value ranges over the `2^k` completions assigning PASS/FAIL to the unresolved components with resolved components fixed; the record contributes the interval `[m_min(x), m_max(x)]` over those patterns. Enumeration of unresolved assignments across the entire 80-record bank is explicitly NOT performed. All four contrasts — Δ_A, Δ_B, Δ_S-extra and I(g, A, B) — receive this identical treatment; no contrast is bounds-free.
>
> **Aggregate estimand and bounds (CORRECTED in v1.2 — the 1/80 factor).** Each `L(g, v)` is a mean over 80 records (:48), so every aggregate contrast carries the factor 1/80: `Δ(g) = (1/80) Σ_x d(x)` and `I(g, A, B) = (1/80) Σ_x i(x)`. The full-bank bounds are therefore
> `Δ_min(g) = (1/80) Σ_x m_min(x)` and `Δ_max(g) = (1/80) Σ_x m_max(x)`, and identically `I_min(g) = (1/80) Σ_x m_min(x)`, `I_max(g) = (1/80) Σ_x m_max(x)` for the interaction. (v1.1.1's unscaled sums are withdrawn — GPT: "Without division by 80, the result is on the wrong scale.") Closed form for the singles, equivalent to enumeration (2,000-trial cross-check, entry-39 receipt): `Δ_max(g) = (1/80) · ( Σ_{x: both resolved} d(x) + |{x : at least one of the two versions unresolved}| )`, and `Δ_min(g)` with the subtraction of that same count. Bounds are deterministic worst-case envelopes over the unresolved completions — attained simultaneously across records because completions are per-record independent — and are NOT statistical confidence intervals. Bounds are computed **per record by pattern enumeration**, never by independently combining version-level averages, which would ignore that the unresolved records are the same matched records across versions and produce incorrect joint bounds. The full per-input distribution (determined records) and the list of undetermined records with their intervals are reported; the cancellation rule (:70–72) is unchanged.

**Justification.** Preserves matching (GPT's two-view structure); the bounds machinery is now uniform over all four E1 contrasts, on the correct 1/80 scale, with extremal patterns that actually attain the stated extremes. Claude's confirmation of the {−2,…,2} range is recorded.

---

## C4 — Deviation features: fixed zero sentinel + defined indicator (ANALYSIS_SPEC §4 :93–94) — ACCEPTED by GPT, plus v1.2 addendum

**v1.0 text (:93–94):**
> `| d_meandev_s | mean of |returned − expected| over wrong integer outputs in s; NaN + defined=False when undefined |`
> `| d_maxdev_s | max of |returned − expected| over wrong integer outputs in s; NaN + defined=False when undefined |`

**Defect.** NaN values enter a ridge design matrix with no specified treatment. Confirmed by GPT and Claude.

**Replacement text (exact, unchanged from v1.1):**
> `| d_meandev_s | mean of |returned − expected| over wrong integer outputs in s; **0 when undefined** (no wrong integer outputs in s), with companion indicator d_meandev_s_defined = False |`
> `| d_maxdev_s | max of |returned − expected| over wrong integer outputs in s; **0 when undefined**, with companion indicator d_maxdev_s_defined = False |`

**Justification (unchanged).** A wrong integer output has `|returned − expected| ≥ 1`, so 0 is never a genuine deviation value (GPT): the sentinel is out-of-domain by construction and unambiguous, avoiding fold-specific imputation. The indicator columns carry the missingness; ridge absorbs the collinearity. Standardization remains fitted on training data only, inside every fold (:140–141 unchanged). No imputation is "fitted" because none is needed — the sentinel is fixed before any data exists.

**v1.2 addendum (GPT §4):** the same fold-fitted standardization is subject to the zero-variance rule of the C5 addendum: a training-fold-constant column — which the `_defined` indicators can be (e.g., all-defined in a fold) — maps to 0 for every row, never to division by zero or NaN. **GPT review status: accepted.**

---

## C5 — `other` failure-manifestation count added (ANALYSIS_SPEC §4 :86–94) — ACCEPTED in principle, plus v1.2 addendum

**v1.0 context.** §2 (:32–34) permits manifestations "wrong answer, invalid return type, exception, timeout/resource breach, other explicitly defined status"; the §4 table counts only wrong answer / invalid return / exception (+ unresolved coverage).

**Defect (GPT, detail 1).** A permitted manifestation class has no feature column; the enriched arm would be blind to it while the typed record retains it.

**Replacement text (exact, unchanged from v1.1):** add row after `d_exception_s`:
> `| d_other_s | count of FAIL records in s whose typed manifestation is classified other (explicitly defined status, excluding timeout/resource, which remain reserved columns until the execution protocol exists) |`

**v1.2 addendum (GPT §4 — zero-variance standardization rule, pre-declared):** numeric feature standardization inside each fold uses the training fold's mean and standard deviation (:140–141 unchanged). If a training-fold feature has **zero variance** (constant column — `d_other_s` is the motivating case, constant 0 if `other` never occurs; the rule applies to any column, including C4's indicators), the standardized column is **defined as 0 for every row** (training and validation rows alike): no division is performed, no NaN or ±∞ can be produced, the column's coefficient is 0 by construction, and the column is still reported rather than dropped (consistent with :101–102). **GPT review status: accepted in principle with this specification demanded — supplied.**

---

## C6 — `d_order_inconsistent` defined and added to the enriched arm (ANALYSIS_SPEC §4, §6 :131–134; BANK_DESIGN §6 :136–138) — ACCEPTED in principle, plus v1.2 addendum

**v1.0 text (BANK_DESIGN :136–137):**
> `The D6 permutation pairs are diagnostic-only instruments for the order-invariance feature (ANALYSIS_SPEC.md §4, d_order_inconsistent).`

**Defect.** The referenced feature does not exist anywhere in ANALYSIS_SPEC v1.0 (table :86–94, aggregates :96–98, enriched arm :131–134). Confirmed by GPT and Claude.

**Replacement text (exact, unchanged from v1.1.1):** add three rows to the §4 table:
> `| d_order_pairs_resolved | count of D6 canonical pairs (of 4) where BOTH orderings resolved (status PASS or FAIL, any manifestation) |`
> `| d_order_pairs_comparable | count of D6 canonical pairs where both executions resolved AND both returned comparable values — exact int return values (PASS, or FAIL with a wrong-integer output). Pairs where either execution ended in invalid return type or exception have no comparable value and are excluded here while remaining visible in d_order_pairs_resolved |`
> `| d_order_inconsistent | count of D6 canonical pairs, among the comparable pairs, whose two returned integer values differ. Value-based only |`

**v1.2 addendum (GPT §4):** the feature table states explicitly that `d_order_inconsistent` is a **count** and `d_order_pairs_comparable` is its **denominator**; **both columns are fed to the predictive model** (as the enriched arm intends). The rate `d_order_inconsistent / d_order_pairs_comparable` may additionally be reported descriptively and is **undefined (reported as null) when the denominator is 0** — it is never silently set to 0 and never imputed.

**Justification (unchanged core).** GPT's comparability condition adopted: a FAIL does not imply a comparable return value exists, so the inconsistency count is restricted to comparable pairs, with the evaluation count recorded at two levels (resolved, comparable). Correctness and order invariance remain separate measurements; a correct solver is order-invariant by (F-ORD); identical wrong values under both orderings count as consistent (an order-invariant bug). Enriched arm (:131–134) amended to include all three columns; BANK_DESIGN's cross-reference becomes true. **GPT review status: accepted in principle with the count/denominator clarification demanded — supplied.**

---

## C7 — `coverage_diag`: definition written, excluded from both arms (ANALYSIS_SPEC §4 :96–98, §6 :130) — ACCEPTED by GPT, unchanged

**v1.0 text (:96–98):**
> `Aggregate baseline columns: k_fail (total diagnostic FAIL count), k_unresolved (total diagnostic UNRESOLVED count), family (parent algorithm family Z from PARENT_DESIGN.md §4 — prespecified context variable), coverage_diag.`
**v1.0 text (:130):**
> `- **Baseline arm:** ridge regression on k_fail, k_unresolved, family.`

**Defect.** Column list and arm specification disagree (GPT's extra point 1; Claude's "partly right" resolved in GPT's favour on line-by-line reading).

**Replacement text (exact, unchanged from v1.1):**
> `Aggregate columns: k_fail, k_unresolved, family, coverage_diag, where coverage_diag = (resolved diagnostic records)/64 = 1 − k_unresolved/64 per solver (Coverage definition of §2 applied to the 64-record diagnostic bank).`
> `- **Baseline arm:** ridge regression on k_fail, k_unresolved, family. coverage_diag is REPORTED but EXCLUDED as a predictor in both arms: it is an affine function of k_unresolved (1 − k_unresolved/64) and would add no information while duplicating a column (GPT).`

**Justification.** GPT's identity holds under the §2 coverage definition; exclusion is pre-declared before any data exists. Reporting keeps coverage_diag visible (§7 rule 1). **GPT review status: accepted ("an affine function of k_unresolved, so reporting it without using it as a predictor is appropriate").**

---

## C8 — E3 target under unresolved held-out outcomes: OWNER DECISION SLOT (ANALYSIS_SPEC §6, with §5 :116–119) — OPEN, unchanged in substance

**v1.0 gap.** §5 defines Q and its unresolved-case reporting (Q_resolved + coverage + bounds), but §6 never states which target the E3 regression fits.

**Options (written before any data exists, per GPT and Claude):**
- **Option 1 (GPT — strict).** E3 proceeds only if all 150 bodies have complete, resolved held-out outcomes on all 80 records; otherwise E3 = `NOT_ESTIMABLE` with the precise reason, and unresolved counts + Q bounds are reported descriptively. Pro: single well-defined target Q for every body; no subset scoring. Con (Claude): timeout classification needs an execution protocol that does not yet exist, so unresolved counts are unknown and Option 1 may be NOT_ESTIMABLE by construction.
- **Option 2 (Claude — threshold).** Pre-declare a maximum unresolved fraction τ (e.g., 0.025 = 2/80 per body); E3 proceeds only if every body is at or under τ. Requires a target definition for bodies with unresolved records — which reintroduces either subset scoring (rejected by GPT) or a convention that §5 currently forbids (counting unresolved as wrong). Any threshold rule must also specify the target exactly, before data. **GPT's renewed assessment (this round): "Option 2 is not ready because a threshold alone does not define a common prediction target."**
- **Option 3 (Claude — descriptive only).** E3 is declared descriptive-only from the outset: no baseline-vs-enriched model comparison is fitted; the §4 features and Q outcomes are reported descriptively. Removes the estimand entirely; nothing to gate. **GPT's renewed assessment: "a legitimate decision if the owner decides to abandon the predictive comparison, but it removes E3 rather than resolving its missing-outcome problem."**

**GLM recommendation (unchanged):** Option 1 — the only option whose target is exactly the preregistered Q with no redefinition; an honest `NOT_ESTIMABLE` is an acceptable outcome for an exploratory secondary estimand (§6 item 9 already provides the machinery); the descriptive fallback under Option 1 is exactly Option 3's content, so nothing is lost.

**GPT's renewed recommendation (recorded verbatim in substance, this round):** Option 1 — "E3 is estimable only if all 150 versions have resolved outcomes on all 80 held-out records. Otherwise E3 is NOT_ESTIMABLE, with coverage and correctness bounds reported descriptively." GPT explicitly reconfirms: "The choice remains yours. I am not treating my recommendation as authorization."

**STATUS: OPEN — OWNER DECIDES BEFORE ANY DATA EXISTS OR THE ANNEX OPENS.** No default is applied; until the owner decides, E3 has no runnable target specification. (Claude's addition adopted: the decision is scheduled before the annex, as step 5 of the agreed sequence.)

---

## C9 — Bank generation pinned to byte-reproducibility (BANK_DESIGN §4 :62–79) — REVISED in v1.2

**v1.0 text (:62–66):**
> `- Generator: Python 3.11+ random.Random (to be pinned exactly by the execution protocol before any solver execution; bank regeneration is deterministic under the pinned interpreter).`
> `- Seeds: SEED_HELDOUT = 20261101, SEED_DIAGNOSTIC = 11052026. Seeded generators are created independently per bank; record order follows generation order.`
**v1.0 text (:67–69):**
> `- Every record carries: input_id, amount, coins (as-given order), canonical_id, stratum, rule_id, rule_params, and a record_sha256 computed over the canonical JSON serialization of the record at file freeze.`

**Defect (GPT, finding F).** Seeds + ranges + guards do not fully determine the sampling process: within-range distributions, per-record draw order, distinctness handling, and redraw RNG consumption are unspecified.

**Amendment history (owned).** v1.1 pinned uniform draws, a global field draw order ("amount, then n, then coins"), collision-redraw consumption, and a "single RNG stream in stratum order". GPT's review identified four residual gaps, all confirmed against the frozen text: (i) the global draw order is CONTRADICTED by D1's own rule (:126 — the amount pattern is a function of `c_min`, unknown until coins exist), and gives no construction for H2's forced coin 1 (:91), H7's constructed zero-answer (:96), or H8's anchored sets (:97); (ii) "single RNG stream" conflicts with v1.0 :65–66 ("Seeded generators are created **independently per bank**") — v1.2 states the intended meaning explicitly: one stream WITHIN each bank, two banks with their separate frozen seeds, never one shared stream; (iii) "canonical JSON serialization" (:67–69) is not an exact serialization rule, and as written the record hash is self-referential (the record's hash computed over a serialization that includes the hash); (iv) stratum quotas ("≥ 3 records with amount = 0 or 1", "≥ 4 records contain coin 1", ":103 H2/H4 rules include match amounts", ":105–109 repeated-use verification") need named forced records, not aspirations.

**Replacement text (exact, added to §4; supersedes v1.1's items 1–6):**

> **Sampling and construction conventions (pinned before any bank file exists):**
>
> **1. Uniform inclusive ranges.** Every range in §5/§6 is inclusive and sampled uniformly: `[lo, hi]` via `rng.randrange(lo, hi + 1)`. All randrange calls have range width ≥ 2 (no degenerate single-value calls exist in the pinned procedures; a single-valued quantity is set deterministically and consumes no randomness).
>
> **2. Draw order is per-stratum (REPLACES v1.1's global "amount, n, coins" order).** The record's JSON key order is canonical (item 5) and is independent of the random DRAW order. Where a stratum's frozen rule derives one field from another (D1's amounts from `c_min`; D3/H7's amounts from the drawn coin set or gcd; D2's amount equal to the drawn match coin; H2-1/H4 forced-match amounts from the drawn coins), the dependency is drawn in construction order — coins and their derived quantities first, dependent amounts last. Strata without dependencies use the fixed order `amount`, `n`, `coins` (D7, D8, H5, H3, and the non-match records of H1/H2/H4/H6). The complete per-stratum order is item 3's table; no other order is permitted.
>
> **3. Per-stratum construction procedures (NEW — exact).** "Record k" is k-th in generation order within the stratum. Forced placements are deterministic (consume no RNG); all other quantities follow the draws shown. Collision handling: a coin colliding with an already-drawn coin of the same record is redrawn immediately (one randrange call per attempt). After drawing, every record passes the common pipeline: (a) within-record coin distinctness (by construction above); (b) validity guard — assert §1 constraints; failure ABORTS generation (a generator bug, never a study finding, :75–76); (c) int32 guard — the primary oracle computes the answer; > 2,147,483,647 → the ENTIRE record is redrawn by re-running its construction from its first draw (consuming exactly the RNG calls a fresh candidate would consume), logged per record (:70–74); (d) within-bank canonical-collision check — if `(amount, tuple(sorted(coins)))` equals that of an earlier non-permutation record of the same bank, the later record is redrawn whole (same consumption rule), logged (permutation pairs of D6/H6 are exempt by design, §2.2); (e) coverage-mandate verification per notes :100–115 — see item 3c-failsafe below.
>
> | Stratum | Pinned construction (record k) |
> |---|---|
> | D1 boundary-amount (8) | Per record: `n = randrange(1, 5)`; coins: n distinct draws from [1, 20] (the "small coin sets" pin: mirrors H1's ranges; keeps every pattern amount ≤ 2·c_min + 1 ≤ 41 ≤ 5000); `c_min = min(coins)`; **amount = PATTERN[k], NOT drawn**: PATTERN = [0, 1, 2, c_min − 1, c_min, c_min + 1, 2·c_min, 2·c_min + 1] exactly as :126. Draw order: n → coins → (derived) amount. rule_params: {c_min, pattern_index}. |
> | D2 exact-match (8) | Per record: distractor count `m = randrange(1, 5)` ("1–4 distractor coins"); match coin `c* = randrange(1, 5001)`; m distractor coins distinct from each other and from c* in [1, 5000]; **amount = c*** (deterministic). Draw order: m → c* → distractors → (derived) amount. rule_params: {match_coin}. |
> | D3 unreachable (8) | Records 1–4 (min-coin mechanism): `n = randrange(2, 7)`; coins distinct in [1, 5000]; if `c_min = 1`, redraw the whole coin set (unreachable-by-min-coin needs c_min ≥ 2); **amount = randrange(1, c_min)** (≥ 1 so the oracle answer is 0, not the amount-0 answer 1). Records 5–8 (gcd mechanism): `g = randrange(2, 11)`; `n = randrange(2, 7)`; coins = g·t with t distinct in [1, ⌊5000/g⌋]; **amount drawn until g ∤ amount**: `amount = randrange(1, 5001)`, redrawing on divisibility (each attempt one call). Oracle verifies answer 0 at generation. rule_params: {mechanism: "min-coin" | "gcd", g?}. |
> | D4 modular-parity (8) | Records 1–2: all-odd coin sets (coins = 2t − 1, t distinct in [1, 2500]; n = randrange(2, 7)), amount = randrange(0, 5001) constrained even (redraw on odd). Records 3–4: all-odd coin sets, amount odd. Records 5–8: coin gcd exactly 2 — coins = 2t, t distinct in [1, 2500], with the FIRST t forced odd (guarantees overall gcd = 2, not 4); amount odd in [1, 5000] (answer 0, oracle-verified). rule_params: {mechanism: "odd-even-amt" | "odd-odd-amt" | "gcd2"}. |
> | D5 non-greedy (8) | Records 1–2: the frozen exemplars verbatim — coins {1, 3, 4}, amount 6 and 10 (no RNG for these two amounts). Records 3–8: "1,3,4-type" sets — coin 1 placed deterministically, n − 1 further coins distinct in [2, 9] (n = randrange(3, 6)), amount = randrange(5, 31); the generator then checks largest-first greedy count ≠ oracle optimal count; if equal, the amount is redrawn (logged) until they diverge. rule_params: {anchor: bool}. |
> | D6 reorder-pairs (8) | Instances 1–4: `n = randrange(3, 9)`; coins distinct in [1, 200]; amount = randrange(10, 201). Each instance yields two records: as-drawn ordering + its Fisher–Yates permutation under rng_diag (:136, adjacent input_ids, shared canonical_id). Draw order: amount → n → coins → shuffle. rule_params: {pair_id, ordering: "original" | "permutation"}. |
> | D7 wide-n (8) | Default order: amount = randrange(50, 501); n = randrange(50, 301); coins: n distinct draws from [1, 5000]. rule_params: {} |
> | D8 large-amount (8) | Default order: amount = randrange(2000, 5001); n = randrange(3, 31); coins: n distinct draws from [1, 5000]. int32 guard expected to fire on some candidates (by design — it is the guard's purpose, :70–74, :159–160). rule_params: {} |
> | H1 tiny-amount (12) | Records 1–3 (H1-EDGE, satisfies ":90 ≥ 3 records with amount 0 or 1" by construction): amount = randrange(0, 2). Records 4–12: amount = randrange(2, 13). All records: n = randrange(1, 5); coins: n distinct draws from [1, 20]. Amount-0 records: oracle answer must be 1 (:102, verified). rule_params: {edge: bool}. |
> | H2 small-amount (12) | Records 1–4 (forced coin 1, satisfies ":91 ≥ 4 records contain coin 1"): coin 1 placed deterministically; n = randrange(2, 7); remaining n − 1 coins distinct in [2, 60]. Record 1 additionally carries a match amount per :103: **amount = max(coins)**, redrawing the whole record (from its first coin draw) if max < 13 — with coin 1 present and amount ≥ 13 the oracle answer is ≥ 2 automatically. Records 2–12: amount = randrange(13, 61). Records 5–12: all n coins drawn distinct in [1, 60]. Every H2 record: oracle answer ≥ 2 checked and logged (:110); failure → whole-record redraw. Draw order: n → coins → amount. rule_params: {forced_coin_1, match_amount}. |
> | H3 single-coin (8) | Default order: amount = randrange(0, 5001); coin = randrange(1, 51); n = 1. Exact match and divisibility structure emerge; oracle verifies. rule_params: {} |
> | H4 two-coin (8) | Records 1–2 (match amounts per :103/"exact matches with distractors", :94): two distinct coins drawn in [1, 5000]; **amount = max(coins)**, whole-record redraw if max < 20. Records 3–8: amount = randrange(20, 5001); two distinct coins in [1, 5000]. Draw order: coins → amount. rule_params: {match_amount}. |
> | H5 many-coins (10) | Default order: amount = randrange(100, 2001); n = randrange(30, 121); coins: n distinct draws from [1, 5000]. rule_params: {} |
> | H6 large-amount (10) | Records 1–6 (singletons): amount = randrange(3500, 5001); n = randrange(5, 41); coins: n distinct draws from [1, 5000]. Records 7–10 (H6-REORDER): 2 instances drawn with the same ranges, each emitted as original + Fisher–Yates permutation under rng_hold, adjacent input_ids, shared canonical_id (:95). rule_params: {singleton: bool} / {pair_id, ordering}. |
> | H7 unreachable (8) | Records 1–4 (min-coin): n = randrange(2, 7); coins distinct in [1, 5000]; whole-coin-set redraw if c_min = 1; **amount = randrange(1, c_min)** (answer 0, oracle-verified at generation :104). Records 5–8 (H7-ZERO gcd): g = randrange(2, 11); n = randrange(2, 7); coins = g·t, t distinct in [1, ⌊5000/g⌋]; amount = randrange(1, 5001) redrawn until g ∤ amount. rule_params: {mechanism, g?}. |
> | H8 rich-combination (12) | Records 1–6 (anchor {1, 2, 3}): anchor placed deterministically; n = randrange(3, 9); further n − 3 coins distinct in [4, 5000]; amount = randrange(6, 801). Records 7–12 (anchor {1, 3, 4}): record 7 is the FROZEN exemplar verbatim — coins {1, 3, 4}, amount 6 (the non-greedy counterexample family of :111–112; greedy 4+1+1 = 3 vs optimal 3+3 = 2); records 8–12: anchor {1, 3, 4} placed, further coins distinct in [2, 5000] \\ {1, 3, 4}, amount = randrange(6, 801). Every H8 record: oracle answer ≥ 2 checked and logged (:110) — automatic with coin 1 present and amount ≥ 2, verified regardless. Draw order: n → coins → amount. int32 guard applies (answers grow quickly; the guard redraws whole records, logged). rule_params: {anchor: [1,2,3] | [1,3,4], anchor_fixed: bool}. |
>
> **3a. Repetition-mandate failsafe (:105–109).** After generation, for each of H1–H4 the generator logs the records satisfying the repeated-use predicate (answer exceeds the number of distinct once-only multisets; e.g. amount > sum of distinct coins, or a coin with multiplicity ≥ 2 in some optimal multiset). If a stratum has none, its records are regenerated one whole record at a time (same RNG consumption rules) until one satisfies the predicate; all attempts are logged. The oracle work this requires is the same oracle already mandated at generation by the int32 guard (:70–74) — no new oracle authority is created.
>
> **4. RNG protocol (CORRECTED — replaces v1.1's "single RNG stream" wording).** Per v1.0 :65–66, quoted: "Seeded generators are created independently per bank." Pinned: `rng_diag = random.Random(11052026)` is the ONLY generator for the diagnostic bank; `rng_hold = random.Random(20261101)` is the ONLY generator for the held-out bank. **One stream per bank; the two streams are never shared, crossed, or derived from one another; no draw for one bank ever consumes the other's stream.** Within a bank, its single stream is consumed in one deterministic global order: strata in order D1→D8 (diagnostic) / H1→H8 (held-out); records in generation order within a stratum; fields in the stratum's construction order (item 3); collision redraws immediately after the rejected attempt; int32/canonical/mandate redraws re-consuming exactly what a fresh candidate would consume. Method whitelist: `random.Random.randrange(lo, hi+1)` and `random.Random.shuffle` (Fisher–Yates, D6/H6 permutations only). No other randomness source exists in the generator (no numpy, no `random` module globals, no time- or entropy-based reseeding, no `random.sample`).
>
> **5. Canonical JSON serialization and record hashing (NEW — exact).** Payload = the record object with exactly the fields `input_id`, `amount`, `coins` (as-given order, array of integers), `canonical_id`, `stratum`, `rule_id`, `rule_params`, `int32_guard` — where `int32_guard = {status: "accepted" | "redrawn", redraws: k}` is the per-record guard log that :73 requires "in the bank file", hereby reconciled with the :67–69 field list as an explicit payload field. **`record_sha256` is NOT part of the payload** — this removes the self-reference in :67–69's "hash over the record". Serialization of the payload: `json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False)` encoded to UTF-8. Pinned: keys in lexicographic order; no whitespace; integers in JSON decimal grammar (no leading zeros, no `+`); no floats anywhere in a record (all numeric fields are integers; `rule_params` values are int/str/bool only, per the per-stratum schemas of item 3); all strings ASCII (identifiers from fixed alphabets — "D1"…"H8", "H1-EDGE", "H6-REORDER", "H7-ZERO", "original"/"permutation", etc.), so `ensure_ascii` is pinned for completeness though inert. `record_sha256 = hashlib.sha256(payload_bytes).hexdigest()` (lowercase hex), added as a field only in the WRITTEN record. File format: UTF-8 JSON Lines, no BOM, one record per line — the canonical serialization of (payload + record_sha256) — each line terminated by "\n", final line included; guard/redraw logs beyond the `int32_guard` field go to a sidecar JSONL with the same conventions. Byte-reproducibility claim = frozen script (item 6) + frozen seeds (:65–66) + pinned interpreter (item 7) + these conventions; the bank JSON files remain the authoritative artifacts (:78–79). ANY deviation from any pinned item ⇒ new bank version, full regeneration from scratch, incident reported to the owner (:172–174) — banks are never patched in place and seeds are never silently adjusted.
>
> **6. Generator script freeze (carried from v1.1, hardened).** The generator is a single script; the seeds are hardcoded as the frozen v1.0 literals (20261101 / 11052026); the script accepts no arguments and reads no configuration; it is hash-recorded (sha256) and published beside the bank files BEFORE generation; regeneration uses the byte-identical script.
>
> **7. Interpreter pin before bank GENERATION (carried from v1.1).** Bank generation does not start until the execution protocol names the exact interpreter version; regeneration cross-checks (:78–79) run under the same pin.
>
> **8. Cross-bank disjointness (explicit failsafe).** The §2 machine check (`canonical(diagnostic) ∩ canonical(held-out) = ∅`) runs at file freeze; a violation ABORTS acceptance, the incident is reported to the owner, and any remedy goes through versioned regeneration (:172–174) — never through silent re-draws or seed changes.

**Justification.** Closes GPT's four named gaps: (i) item 2 + item 3 give every stratum an exact construction whose draw order is consistent with its own frozen rule (D1's `c_min` dependency resolved by drawing coins first and taking the amount pattern as derived, not drawn); (ii) item 4 states the two-independent-streams structure explicitly, matching :65–66 rather than contradicting it; (iii) item 5 pins serialization to byte level and removes the self-referential hash; (iv) item 3's forced-record assignments turn every ":≥" quota and every :100–115 mandate into a named, checkable construction. Legal under the freeze discipline: no bank file exists yet, and BANK_DESIGN §9 (:172–174) contemplates versioned correction before outcomes.

---

## Consistency matrix and effect summary

| Correction | File touched | v1.0 lines | Other sections affected | GPT review status (2026-11-01) |
|---|---|---|---|---|
| C1 G22 | PARENT_DESIGN | :170, :271 | §11 near-duplicate report (construction time) | REVISED in v1.2 (direction, complexity, terminal states) |
| C2 K5 | PARENT_DESIGN | :64, :236–239 | §3.4 risk note becomes population-max (no text change needed) | ACCEPTED |
| C3 E1 | ANALYSIS_SPEC | :51–54, :63–68 | §7 rule 1 reporting unchanged | REVISED in v1.2 (examples, 1/80 scale, all contrasts) |
| C4 dev sentinel | ANALYSIS_SPEC | :93–94 | :131–134 arm list unchanged (indicators already listed) | ACCEPTED + zero-variance addendum |
| C5 other count | ANALYSIS_SPEC | :86–94 | reserved timeout columns :100–102 unchanged | ACCEPTED in principle + zero-variance rule |
| C6 order feature | ANALYSIS_SPEC (+BANK_DESIGN xref) | :131–134 | BANK_DESIGN :136–137 becomes consistent | ACCEPTED in principle + count/denominator addendum |
| C7 coverage_diag | ANALYSIS_SPEC | :96–98, :130 | §7 rule 1 unchanged | ACCEPTED |
| C8 E3 target | ANALYSIS_SPEC | §6 | §5 unchanged; item 9 machinery reused | OPEN — owner decides (GPT recommends Option 1) |
| C9 bank pinning | BANK_DESIGN | :62–64 | §9 :168–170 satisfied earlier | REVISED in v1.2 (stratum algorithms, RNG, serialization) |

**Explicit non-authorizations (owner, 2026-11-01, reaffirmed by GPT this round):** no solver bodies (0/150), no execution, no commits, no pushes. v1.0 documents remain byte-frozen as the historical reference; this record is the sole correction instrument until the review chain completes.

**Open owner decisions (none blocking the Claude → GPT review of this record):**
1. C8: E3 unresolved rule — Option 1 / 2 / 3 (needed before the annex opens, not before this review).
2. Second-commit push of the updated worklog snapshot (entries 30–39) to the handoff branch — per work order :217.
3. GitHub token disposition — recommendation to revoke stands on record (GPT, Claude, GLM); owner's standing instruction is to keep it; GLM acts on the owner's word only.

---

## Changelog

- **2026-11-01, initial draft (v1.1-draft):** C1–C9 as issued. sha256 `083cd85a1bfb9abd7afc9f7e19b34cdc8d0cdd61a7592816be2f3479aaa462ae` (preserved per GPT's document-control requirement).
- **2026-11-01, amendment (v1.1.1-draft), responding to GPT's first conditions:** C1 + explicit recursion-limit mandate; C1 near-duplicate re-ranked (PRINCIPAL G20, SECONDARY G17, G21 artifact); C3 + 2^k per-input clarification + both complete-case conventions; C6 + comparability distinction (three columns). On-disk sha256 `663193006fa3c94a8601eee4b6ac2ed499b0443c342da71914fc572e68d9c78f` — the exact text GPT reviewed in the current round. Header/changelog version mismatch flagged by GPT and resolved as of THIS version.
- **2026-11-01, this draft (v1.2-draft), responding to GPT's required revision:** C1 two-pointer reversed to descending amounts + worked example + O(n log n + nA + A) without collapse + A=0 immediate return + amount-zero states never memoized + explicit distinctness premise for the state count; C3 extremal patterns corrected to the unique (1,0,0,1)/(0,1,1,0) loss patterns, aggregate bounds divided by 80, uniform bounds machinery extended to all three single contrasts, complete-case normalization pinned; C9 per-stratum draw orders and construction procedures (D1–D8, H1–H8) with forced-record quotas, two-independent-stream RNG protocol stated explicitly, exact canonical-JSON serialization with record_sha256 excluded from the hashed payload; C4/C5 zero-variance standardization rule; C6 count/denominator clarification; header aligned to the single identifier **1.2-draft**. Verification receipts in worklog entry 39 (script `scripts/verify_v12_math.py`; editorial verification only — no solver bodies, no bank generation, no pipeline execution). sha256 of this file recorded in worklog entry 39 at delivery; to be re-taken at acceptance.
