# DOCTOR — TASK 02 — LC518 security containment patch preparation — VALIDATION REPORT

**Date:** 2026-11-03
**Author:** PyCharm local execution agent (Qoder CLI)
**Status:** PREPARED, NOT PUBLISHED. Nothing pushed, merged, deleted, or dispatched. No history rewritten.
**Reviewers:** GPT, Claude, GLM — publication is reserved to the owner/reviewers.

## 1. Deliverables

Directory: `C:\Users\pakla\PycharmProjects\lc518_containment_2026-11-03\`

| Artifact | SHA-256 |
|---|---|
| `patches/master/0001-LC518-security-containment-remove-activated-generato.patch` | `79d714e58b31b09c911a3584a8e1b137397798ef85468a59fb871cc05a258c34` |
| `patches/foued2-patch-1/0001-LC518-security-containment-remove-activated-candidat.patch` | `b98129db68a1d03397a0015fd687bb7914433227c430c3aaba53f9fe5d509f5c` |
| `patches/recovery/0001-LC518-security-containment-remove-activated-candidat.patch` | `f62a18be02e52fc364a118225555a0bd4409ba06b7b0e3d628ee64f2900975fe` |
| `wt-master/`, `wt-foued2-patch-1/`, `wt-recovery/` | prepared trees, inspectable directly |

Local containment branches (created in this repo's `.git`, NOT pushed):
- `lc518-containment/master` → `82b666e` (parent `b3e98740716bd79ecc99346241d633fd405d49d8`)
- `lc518-containment/foued2-patch-1` → `59ae815` (parent `e22da84b41d5009628dc55a59f76e0aa442095a3`)
- `lc518-containment/recovery-2026-11-02` → `7921e35` (parent `a4ec1148698fe6612c5e873f1193069538a206e3`)

All three patches were verified with `git apply --check` against their exact original tips (all pass).

## 2. Per-branch changes

### 2.1 master (patch 1 — protected branch; publish via pull request)

Removed:
- `lc518_generator_state2.py` — activated candidate (blob `ef5a0fc8…`, content `1335a42d…`)
- `activation_diff.txt` — published one-line activation recipe (blob `4d2c6f70…`, content `578d1716…`)
- `.github/workflows/lc518-github-generation.yml` — dispatch entry point (blob `729dc5a3…`)

Updated: `SHA256SUMS` (2 rows remain; removed rows quoted in header comment).
Added: `LC518_GENERATION_HOLD.md` (GO consumption record, removal table, restrictions).
Kept: `lc518_generator_state1.py` (locked, verified `False` at lines 36/1126/1153), `execution_protocol_v1.md`, `VERIFICATION_LOG.md`, review ZIP, message ZIPs. (Root README has no LC518 section — no edit needed; `b3e9874` touched only the workflow file.) **[Superseded 2026-11-04 — see §8: the state-1 file was fully *configured* and was removed by Task 03.]**

### 2.2 foued2-patch-1 (unprotected; separate containment commit)

Removed: the three master items above, plus `lc518-publish-set-12-files-run-41591572358.zip`
- Reason: neutral-named members `lc518_generator.py` = `848984ca…` and `lc518_launcher.py` = `014e45c2…` are the **activated state-2 bytes** (verified by in-memory hashing against the gate pins).
- Original ZIP preserved in history: blob `301e8e16…` at `e22da84` (no rewrite).

Added:
- `lc518-bank-artifact-run-41591572358.zip` — bank-only repack, SHA-256 `71f1e76b03161d91a443a891ce0a1821b2bdd7ff70cc97115c6c1a0448bc2df1`. Every retained member is **byte-for-byte identical** to the original (7 bank files incl. both `.rejections.jsonl`, `execution_protocol_github_v2.json`, both test suites); only the two executable source copies are absent.
- `lc518-bank-artifact-run-41591572358.SHA256SUMS` — original ZIP hash + all member hashes + provenance header.
- `LC518_GENERATION_HOLD.md`.

Updated: `SHA256SUMS`.

### 2.3 gpt/lc518-github-recovery-2026-11-02 (unprotected; separate containment commit)

Removed (10 items): both activated candidates (`lc518-150/c9-github-execution/lc518_generator_state2.py` `b4dfdef8…`, `lc518_launcher_state2.py` `79e5ba35…`), both v1 activation diffs, the five `c9-github-generation-package-parts/*.b64` (pre-armed v2 kit, tar `e0be3f2a…`), `scripts/build_lc518_github_locked_package.py` (builder), and **both** LC518 workflows (`lc518-github-generation.yml`, `lc518-github-recovery.yml` — the latter had `contents: write` auto-commit).

Added:
- `lc518-150/provenance/OWNER_GO_RECORD.md` — **exact bytes**, committed blob SHA-256 `5c4cd6eb81d99cbb67217999a46a7af6aee1ff5f368250f601e7759521ae54c1` (verified post-commit) — extracted from the kit tar immediately before part removal.
- `lc518-150/provenance/execution_protocol_github_v2.json` — exact bytes, SHA-256 `9c54ffc2143eef807dad51ee5ba92e494e4588fa4655bd5772f613cec2f343a9` (verified post-commit).
- `lc518-150/provenance/SHA256SUMS` — documents origin (tar `e0be3f2a…`) and non-executable status.
- `LC518_GENERATION_HOLD.md`.

Updated: `c9-execution-recovery/README.md` + `SHA256SUMS`, `c9-github-execution/README.md` + `SHA256SUMS` (containment block inserted above the historical text; removed rows quoted in manifest headers).

Kept: both locked state-1 sources, locked launcher, review generator, protocol v1 JSON/MD, verification log, v1 test suites, the two audit scripts, all LC518 review documents, all unrelated material.

## 3. Validation results (all criteria met)

| Criterion | Result |
|---|---|
| No `BANK_GENERATION_AUTHORIZED = True` in an executable candidate on any tip | PASS — zero matches in `*.py` across all three tips, with one documented exception below |
| No executable state-2 launcher or generator on any tip | PASS — all four state-2 files removed; `git cat-file -e` confirms absence |
| No active LC518 generation workflow on any tip | PASS — no `workflows/` entries remain on any of the three tips |
| No builder capable of recreating the activated package | PASS — `build_lc518_github_locked_package.py` removed; no reconstructible parts remain |
| Locked state-1 sources preserved | PASS — flags verified `False` post-commit **[Superseded 2026-11-04 — see §8: the files were fully configured; one-line flag edits reproduced the activated hashes; removed by Task 03]** |
| Bank artifact + hashes preserved | PASS — repack `71f1e76b…`; members byte-identical; original ZIP hash recorded |
| OWNER_GO_RECORD exact content + hash | PASS — `5c4cd6eb…` verified on the committed blob |
| Run 41591572358 / artifact 13210063805 evidence | RECORDED — referenced in all three hold files (GitHub-side objects; not verifiable via git — cross-check on github.com recommended at publication) |
| Restriction language preserved/restated | PASS — hold files + README blocks restate: no solver construction (150 bodies stopped), no candidate execution, no predictive fitting, no private-annex access |
| No history rewrite | PASS — three new forward commits only; parents are the exact tips from the task |
| Main workspace untouched | PASS — `research/concentration-math-spec` unchanged; `git status` byte-identical to pre-task state (0 modified tracked files; all untracked files incl. three-world analysis and `.qoder_*` intact) |

### Documented exception (reviewer decision requested)

`scripts/lc518_github_recovery_introspect.py` line 32 retains the string constant `STATE2_AUTH = "BANK_GENERATION_AUTHORIZED = True"`. This is the **auditor** that verified the state1→state2 transition during the recovery work; it contains the literal only as a comparison constant, executes nothing itself (compile-only of its subject, which no longer exists — the script is inert on this tip and would fail immediately), and is not an activation candidate. I kept it as provenance tooling per the minimal-removal instruction. If reviewers prefer zero literal matches, remove the file in a follow-up commit; it is not needed by anything on the tip.

### Decision flagged for reviewer challenge

The publication-set ZIP repack (§2.2). GPT's instructions require both "remove activated generator/launcher candidates from current branch tips" and "preserve the original generation bank artifact and all its hashes"; the original ZIP satisfied only the second. The repack satisfies both, preserves every bank hash byte-for-byte, and records the original ZIP's hash and blob so nothing evidentiary is lost. If reviewers prefer the original ZIP untouched, the master-style patch alone (without the ZIP swap) applies to `foued2-patch-1` as well.

## 4. Mechanical notes

- Environment: commits made by the configured local git user (`DeepSeek`) in temporary worktrees under `lc518_containment_2026-11-03/`. Publication will carry that authorship unless GPT re-authors (`git apply` / `am` as desired).
- Line endings: repo has `core.autocrlf=true` and no `.gitattributes`. All hashes in manifests and this report are of **committed (LF) content**, verified via `git show | sha256sum`. On Windows checkouts text files appear CRLF and a local `sha256sum --check` will not match — pre-existing condition, unchanged by this patch; Linux checkouts verify cleanly.
- The three worktrees remain in place at their containment commits for direct inspection. Cleanup after review (reviewer-run): `git worktree remove ../lc518_containment_2026-11-03/wt-master` (etc.) and `git branch -D lc518-containment/master lc518-containment/foued2-patch-1 lc518-containment/recovery-2026-11-02` if not published.
- A pre-existing stale temp worktree (`AppData/Local/Temp/a1_verify_…/checkout`, prunable) exists in `.git/worktrees` — not created or touched by this task; left as found.
- Publication sequence recommendation: (1) GitHub Settings → Environments → delete or harden `lc518-bank-generation`; (2) apply recovery + patch-1 containment commits; (3) open the master PR; (4) publish a revocation/supersession note for `LC518-GO-2026-11-03-01` if the panel does not recognize the GO as consumed-correctly — the hold files already record consumption, so only a confirming note would be needed.

## 5. Confirmation

No push, no merge, no branch deletion, no Actions dispatch, no history rewrite. No file in the main workspace or the nested clone was created, modified, or deleted. All work occurred in `C:\Users\pakla\PycharmProjects\lc518_containment_2026-11-03\` (deliverables) and git worktree metadata.

## 6. Addendum (2026-11-04) — scratch-ZIP audit per GPT request, ZIP location index, patch review package

GPT accepted the scratch-ZIP discovery as closing a Task-02 gap but declined the phrase "locked state" pending a full audit. Audit performed 2026-11-04; the three claims GPT required are recorded separately below. GPT's framing is adopted: the evidence supports calling this a **pre-activation v1.2 review snapshot with the authorization flag False**; it is *not* shown to be the exact state-1 build, and audit of the flag alone does not constitute an execution-safety audit — hence Claim 3. **GPT review status (2026-11-04): scratch ZIP provisionally cleared for retention; containment patches remain unapproved pending byte-level review of the package in §7.**

### 6.1 Claim 1 — Archive integrity (PASS)

- ZIP SHA-256: `4a7302072fcdda922cad3e9658056af5209e68ed82e26f6420e52e35dc1036f9` — **byte-identical in all three containment worktrees** (`wt-master`, `wt-foued2-patch-1`, `wt-recovery`); git blob `4802959956fd5c1144d3cbf8f5483a5600e049f4` — **identical across all six tips** (three original tips `b3e9874`/`e22da84`/`a4ec114` and three containment tips).
- `unzip -t`: no errors. 10 members, all hashes recorded. Embedded `SHA256SUMS` (9 rows) self-consistent with member bytes.
- The embedded launcher self-pins its companion generator: `EXPECTED_GENERATOR_SHA256 = 6e4281b4…` (launcher line 39) matches the embedded generator's hash — internally coherent package.

| Member | SHA-256 |
|---|---|
| `lc518_generator.py` | `6e4281b4bfd79783b53d93e132a538dc3d120177405e44012081c6db083c0e2f` |
| `lc518_launcher.py` | `c23115b54061cdd490e0d6f87e31e5a067d4ab99d5c4677de19e92ce64eb24a2` |
| `test_lc518_generator.py` | `d6a322bc9c28a9c5537f89a1bb6395bf52a44f79293c07b4f526ad985dfcdf64` |
| `test_lc518_launcher.py` | `febd27e1fd98ed9d27d6e802e50704fa278b504ba2d6555bbab81d0c091953b0` |
| `execution_protocol_v1.json` | `8e2a2913f49f838465885f708cd111bea1c83027c579c9d37157d8c3f9ba65ad` |
| `EXECUTION_PROTOCOL_DRAFT_V1.2.md` | `03f8415e6fc1f71164fb33c8dde2beb3286369510707a3c53d08e4ce3389c4cc` |
| `GENERATOR_HANDOFF.md` | `f6131b3934565d5c05f166ca042c98de71682ea0a2e93bb070aded9295cb7b98` |
| `TEST_RESULTS.txt` | `60ab2603a214db65bf9488a27d3529357d8c22e78ffeff43cdb9ee2193daecf5` |
| `fixture_reproducibility.json` | `176d349f95169afc6e0af178fe936a4ec3fea9183d586cdbdd317593971821cf` |
| `SHA256SUMS` | `09ff74965d342e9fb3a85a4c1364db40e01955df1dbb81f7714c377f8bdb0e3e` |

### 6.2 Claim 2 — Authorization-state inspection (PASS)

- Generator: `BANK_GENERATION_AUTHORIZED = False` (line 36); refusal guards at lines 1126 and 1153.
- Launcher: `BANK_GENERATION_AUTHORIZED = False` (line 45); guard at line 338; cross-check of the loaded generator's flag at line 441.
- Zero of the 10 members contain the literal `BANK_GENERATION_AUTHORIZED = True`.
- Test suites never move the flag toward True: `test_lc518_generator.py:593` patches it **to False** (refusal-path test); `test_lc518_launcher.py:127–128` asserts `OUTPUT_DIR is None` and the flag is False (static lock assertions).
- Documentation scan: no activation recipe anywhere. `GENERATOR_HANDOFF.md` ("Not authorized for bank generation… Bank-generation authorization remains false", and describes the hash-chain requirement that any future GO name the exact activation diff); `EXECUTION_PROTOCOL_DRAFT_V1.2.md` §138/§155 ("authorizes no bank generation… remain locked"); `execution_protocol_v1.json` (`"bank_generation_authorized": false`, status `DRAFT_INCOMPLETE_NOT_AUTHORIZED`).
- Lineage precision: embedded generator hash `6e4281b4…` ≠ locked state-1 on master (`276b9f49f5a3a975c530cc4eca02b0a0f3407ab824d12031f43175a72feb14fe`, verified on the committed blob) and ≠ activated state-2 (`848984ca…`/`014e45c2…`). Structurally parallel to state-1 (identical guard line numbers 36/1126/1153) but distinct content. Correct description: **pre-activation v1.2 review snapshot, flags False** — not the exact state-1 build, not the activated state-2 bytes. Its own handoff calls it "a locked, unconfigured review-build hash, not the final run hash".

### 6.3 Claim 3 — Execution-path review (PASS — no route to bank generation while authorization is false)

**Generator** (`6e4281b4…`, 1163 lines). Imports: `hashlib, json, math, os, random, sys` + `dataclasses/pathlib/typing` only. **No** `os.environ`/`getenv` reads, **no** argv/argparse parsing, **no** subprocess, network, `eval`/`exec`/`__import__`/`importlib`, **no** self-modification, **no** module-level side effects (constants/dataclass/class/def only). Entry point `main()` (line 1148) fails closed on three independent hardcoded gates, in order: `OUTPUT_DIR is None` → refuse; interpreter ≠ exactly (3, 13, 5) → refuse; flag false → refuse (`"REFUSED: separate owner authorization for study-bank generation is absent."`). `run_production()` (line 1118) repeats all three gates. `OUTPUT_DIR` is assigned exactly once in the file (line 35, `None`) and never set by any code path. The only file-writing path (`run_production` → `atomic_publish_fixture_or_bank_package` → `write_all_bytes`) is reachable exclusively through those gates. RNG seeds are hardcoded constants. **As shipped, `python lc518_generator.py` exits at the first gate with a refusal; the flag gate is not even reached.**

**Launcher** (`c23115b5…`, 551 lines). Imports include `subprocess` and `importlib.util` — both traced: `subprocess.run` appears exactly once (line 454, running the hash-pinned published generator under the pinned interpreter); `importlib.util` loads the generator module for validation only (lines 267–282, 438, 495) — a side-effect-free load per the generator review — and the launcher never sets the generator's flag. `main()` → `run()` → `validate_static_configuration()` (line 289) raises unless **all seven** run pins are non-None (lines 290–304): `RUN_ROOT, OUTPUT_DIR, EXPECTED_PYTHON_EXECUTABLE, EXPECTED_SYS_VERSION, EXPECTED_PLATFORM, EXPECTED_INTERPRETER_SHA256, PROTOCOL_SHA256` — **all are `None` at lines 32–38**. Additional mandatory gates even after the pins are filled: launcher's own flag True (line 338); launcher running under the pinned absolute interpreter with full `sys.version`/`platform` identity and interpreter-binary SHA-256 match (lines 313–321); generator/protocol/test-suite source hash pins (lines 326–337); loaded generator's flag `is True` (line 441) and its `OUTPUT_DIR` agreement (lines 439–440). Environment: `os.environ` is only copied through to the child with `PYTHONHASHSEED=0` (lines 451–452) — **no environment variable can influence any pin**. `sys.argv` is recorded into the manifest (line 376) and never parsed. Writes occur only inside a freshly created, previously absent `RUN_ROOT` (lines 360–364). **As shipped, `python lc518_launcher.py` prints `LAUNCHER_REFUSED: RuntimeError: execution protocol is not fully pinned: …` and exits 3 before any filesystem side effect.**

**Route-to-execution conclusion.** Enabling bank generation from this snapshot requires deliberate source edits to at least three independent hardcoded constants in the generator (`OUTPUT_DIR`, the flag, and defeating the interpreter pin) — the first two of which change the generator's hash and break the launcher's own pin (line 332) unless the launcher is also rewritten — plus execution under an exact CPython 3.13.5 binary whose SHA-256 must match a pin that is currently unset. There is no CLI, environment, config-file, network, or dynamic-code route. Direct execution of either file while authorization is false cannot generate a bank.

**Status wording (GPT constraint, 2026-11-04, adopted).** The correct claim is **fail-closed in its shipped configuration** — *not* permanently incapable of execution. A person deliberately editing the source constants and their associated pins could change that. This audit establishes only that no route to bank generation exists as shipped; it does not claim the code is incapable of modification.

### 6.4 Provenance (precise)

- Introduced by commit `082b8a743ef97de67efaf223b6961edc21bef298` — author `foued2 <116307732+foued2@users.noreply.github.com>`, 2026-11-02 20:23:52 +0100, message "Add files via upload", single-file commit (`lc518_generator_scratch_GLM_review_v1.2.zip`, Bin 0 → 48248). Nothing else was in that commit.
- Present on all three original remote branches (`origin/master`, `origin/foued2-patch-1`, `origin/gpt/lc518-github-recovery-2026-11-02`), hence inherited by all three containment branches. **Only one commit in history ever touched it — unmodified since introduction.** Internal member mtimes 2026-11-02 18:51–19:02 (created ~1.5 h before upload). Containment did not add, modify, or remove it; Task-02 report §2.1/§2.3 "review ZIP" references refer to this file.

### 6.5 ZIP location index (retained from provisional addendum, unchanged)

- Original publish-set `lc518-publish-set-12-files-run-41591572358.zip`: not on any tip; recoverable only from git history, blob `301e8e16…` at commit `e22da84` (`git show e22da84:lc518-publish-set-12-files-run-41591572358.zip`). Extraction re-creates activated state-2 bytes — only if the panel requires it, working copy deleted after.
- Repacked bank artifact `lc518-bank-artifact-run-41591572358.zip` (`71f1e76b…`): committed at containment tip `59ae815`; on disk at `lc518_containment_2026-11-03\wt-foued2-patch-1\`.
- `message-70b0882f…` / `message-73aed204…` ZIPs: corrections records + verification map, documents only, inert, pre-existing, unchanged.
- `failure-concentration-study-worktree-15e040e.zip` (PycharmProjects root, 2026-10-13): pre-existing export of this study's frozen state (FREEZE.md, PROTOCOL.md, gates, pilot pack); predates LC518; unrelated; untouched.
- `FREEZE.md` in the main workspace is the study's frozen-instrument record (v0.1, protocol `6c4991cc…`); no LC518 content; never touched by containment.

### 6.6 Patch review package for reviewers (GPT request)

Patches re-verified 2026-11-04 with fresh `git apply --check` against each exact original tip (all three pass; worktrees restored to containment branches afterwards). Patch files unchanged since Task 02 (hashes match §1).

| Patch (under `lc518_containment_2026-11-03\patches\`) | Size | SHA-256 | Binary sections | Applies clean to |
|---|---|---|---|---|
| `master\0001-LC518-security-containment-remove-activated-generato.patch` | 67,193 B | `79d714e58b31b09c911a3584a8e1b137397798ef85468a59fb871cc05a258c34` | none (all-text changes) | `b3e9874` |
| `foued2-patch-1\0001-LC518-security-containment-remove-activated-candidat.patch` | 229,959 B | `b98129db68a1d03397a0015fd687bb7914433227c430c3aaba53f9fe5d509f5c` | 2 (`GIT binary patch` — carries both ZIPs; fully self-contained) | `e22da84` |
| `recovery\0001-LC518-security-containment-remove-activated-candidat.patch` | 249,021 B | `f62a18be02e52fc364a118225555a0bd4409ba06b7b0e3d628ee64f2900975fe` | none (all-text changes) | `a4ec114` |

Change summaries (`git apply --stat`): master — 5 files, +45/−1304 (state2 generator 1163 lines, workflow 128, activation diff 11; adds hold doc 40 + SHA256SUMS update). foued2-patch-1 — 8 files, +72/−1304 (same as master + publish-set ZIP removed / bank-artifact ZIP + manifest added). recovery — 22 files, +124/−3541 (both state2 candidates, both activation diffs, both workflows, 5 kit parts, builder 371 lines, README/manifest updates; adds provenance trio + hold doc).

Audit status: this finding does not authorize publication; containment patches remain under review. The bank-generation GO `LC518-GO-2026-11-03-01` remains recorded as consumed by run `41591572358` and authorizes nothing further.

## 7. Review package (2026-11-04, per GPT request)

`lc518_containment_review_package_2026-11-04.zip` — prepared in the prep directory root, containing:

- `VALIDATION_REPORT.md` — this report (copy as of packaging).
- `MANIFEST_SHA256SUMS.txt` — SHA-256 of every packaged file (itself excluded).
- `patches/master/`, `patches/foued2-patch-1/`, `patches/recovery/` — the three patch files, **including the self-contained binary patch** for `foued2-patch-1`.
- `tree-master/`, `tree-foued2-patch-1/`, `tree-recovery/` — complete file contents of the three containment tips (`82b666e`, `59ae815`, `7921e35`), exported with `git archive` (committed LF bytes, matching all manifest hashes in this report — not CRLF working-tree copies). **[Superseded 2026-11-04 — see §8: this claim was wrong on Windows; `git archive` applied `core.autocrlf` smudge, so r1 exports contain CRLF bytes. Corrected raw-blob exports ship in the r2 package.]**

Reviewer verification recipe:

1. `git apply --check <patch>` on a checkout of the corresponding original tip (`b3e9874` / `e22da84` / `a4ec114`).
2. `git apply <patch>` on that checkout, then `diff -r` the result against `tree-<branch>/` — the diff must be empty.
3. Cross-check any file of interest against `MANIFEST_SHA256SUMS.txt`; ZIP integrity additionally via §6.1 hashes.

The package's own SHA-256 is recorded in the transmittal message rather than inside this report's packaged copy, to avoid self-reference.

## 8. Task-03 record (2026-11-04) — reactivation-route correction (GPT NO-GO remediation)

**GPT's byte-level review of the r1 package returned NO-GO.** The removals in Task 02 were mechanically sound, but retention of the "state-1" files left a one-edit reconstruction route to the activated bytes on every tip. Claude independently verified the finding against the repository; both were reproduced locally before any edit (identical values). Task 03 is correction only: local containment revision, no push/PR/merge/history-rewrite/dispatch, no solver execution, no repository changes by GPT.

### 8.1 The finding (reproduced locally)

The root `lc518_generator_state1.py` retained by Task 02 was **not an unconfigured review snapshot**: `OUTPUT_DIR = "/home/z/lc518_run/bank"` was embedded, the CPython 3.13.5 pin was in place, and `main()` was intact. A single one-line edit (`BANK_GENERATION_AUTHORIZED = False` → `True`) reproduced the exact activated state-2 bytes. On the recovery branch the configured launcher (`RUN_ROOT`/`OUTPUT_DIR`/`EXPECTED_PYTHON_EXECUTABLE` pre-pinned to GitHub runner paths) reproduced its recorded state-2 hash the same way:

| File (location) | Pre-flip SHA-256 | Post-flip SHA-256 (= recorded activated bytes) |
|---|---|---|
| root `lc518_generator_state1.py` (master, foued2-patch-1, and recovery `c9-execution-recovery/`) | `276b9f49f5a3a975c530cc4eca02b0a0f3407ab824d12031f43175a72feb14fe` | `1335a42d06d64cf7e847981fc68eee07945655128e82e7f08bc43e774d1cb41c` |
| `lc518-150/c9-github-execution/lc518_generator_state1.py` (recovery) | `f73b189d37d60b8601d5db73270fe5d88945aab2c286632f126377e28c92eaff` | `b4dfdef828374f321d6b21d6f888bc87f926b5b781e26afa4f49bb009ab7de2c` |
| `lc518-150/c9-github-execution/lc518_launcher.py` (recovery) | `2f33f9d30a1392908789650b5423c2185c420255c3206a1db2c4944fdef4e941` | `79e5ba358485e9427441df5c44674e5dab700e9dd87f4f129f1590b47ef1c6bd` |

Retained protocol documentation (`execution_protocol_v1.md` §13) additionally presented the exact activation diff as a completed procedure. Task-02's claim that no reconstructible activation route remained was therefore **false**; the report rows marked "Superseded" above record where.

### 8.2 Corrections to Task-02 record

- §2.1/§3: the "locked state-1" characterization was wrong in the operative sense — flag `False`, but fully configured; retention violated the hold docs' own requirement (§4) that authorization controls not depend on in-package constants.
- §7: the r1 tree exports contained **CRLF** bytes, not committed LF — on Windows, `git archive` applies the `core.autocrlf` smudge. The r1 manifest honestly hashed the bytes it contained; the export-method claim was the defect. r2 corrects both.
- §6.3 remains accurate for the scratch-ZIP files (unconfigured, three-gate fail-closed in shipped configuration) — a distinct situation from the configured root state-1 files.

### 8.3 New tips (forward commits only; no history rewrite)

| Branch | Task-02 tip (0001) | Task-03 tip (0002) |
|---|---|---|
| `lc518-containment/master` | `82b666e` | `5db757e` |
| `lc518-containment/foued2-patch-1` | `59ae815` | `caa008b` |
| `lc518-containment/recovery-2026-11-02` | `7921e35` | `7679c98` |

Per-branch changes (0002 commits):
- **master / foued2-patch-1:** removed root `lc518_generator_state1.py` (blob `60725f8a…`); `SHA256SUMS` row replaced by provenance comment (state-1 row quoted; protocol row updated — the supersession notice changed the file's hash, handled in the same commit); `execution_protocol_v1.md` superseded (containment notice after the title + VOID note above the §13 diff; historical text preserved); `LC518_GENERATION_HOLD.md` Task-03 addendum (provenance table, residual risk, external-gate requirement).
- **recovery:** removed the three configured files above (blob ids `60725f8a…`, `7a08724b…`, `9605a874…`); both package manifests updated — state-1/launcher rows quoted in headers, the stale `c9-github-execution` README row corrected (`1d73580a…` → `55aa7738…`, the committed README's hash), protocol row updated; `c9-execution-recovery/execution_protocol_v1.md` superseded; hold-doc addendum records all three removals and the retained-files rationale.
- **Retained deliberately:** `lc518-150/c9-github-execution/lc518_generator.py` (`6e4281b4…` — unconfigured v1.2 review build, `OUTPUT_DIR = None`; its one-line flip `475d5c072382bfb7079db23772d113a60943e8907e396e2c2e998dff2f222243` matches no recorded activated hash); `scripts/lc518_github_recovery_introspect.py` (inert auditor, comparison literals only); the scratch ZIP (provisionally cleared, §6); the bank artifact and its manifest (**unchanged**, zip hash re-verified `71f1e76b…`); `lc518-150/provenance/` (owner GO record, protocol v2 — **unchanged**); all unrelated research material.

### 8.4 Post-remediation verification (all PASS)

| Check | Result |
|---|---|
| Five removals absent from tips | PASS — `git cat-file -e` fails for all five paths on all three new tips |
| Single-flip reconstruction scan | PASS — **485** `.py` files across the three tips; method: for every tracked `.py` blob, hash the committed bytes (pre) and the variant with the module-level line `BANK_GENERATION_AUTHORIZED = False` replaced by `True` (post), then compare both against the activated set (`1335a42d…`, `b4dfdef8…`, `79e5ba35…`, `848984cac427547955a04b2e5c379762149ad94a37711a6483008fd55f2c161b`, `014e45c259771b187a0a2323ad4efdf8ab4343a5f62cc8d9b53f59879409b2f9` — the last two recovered from the original publish-set ZIP in history): **zero matches**. Scope: tracked tip blobs only — ZIP-internal members are covered separately in §6, and multi-edit or rewrite variants are out of scope by design |
| Remaining module-level flag | `lc518-150/c9-github-execution/lc518_generator.py:36` only — the unconfigured review build |
| Manifest audit (all six SHA256SUMS) | PASS — every row re-verified against committed bytes; bank-artifact manifest rows verified against the ZIP members; ZIP hash unchanged |
| 0002 patches | PASS — `git apply --check` clean against each 0001 tip; `git apply` + `write-tree` reproduces the exact new tip tree (round-trip MATCH ×3) |
| r2 tree exports | PASS — rebuilt with `git -c core.autocrlf=false archive` (raw blob bytes); counts 304 / 306 / 317; **every exported file byte-identical to its git object** (per-file `git cat-file` hash comparison, zero mismatches) |

### 8.5 Current-tip containment vs history (explicit distinction)

No history was rewritten: every removed file remains recoverable at its recorded blob and at the pre-removal commits (`b3e9874`, `e22da84`, `a4ec114`, `82b666e`, `59ae815`, `7921e35`). The 0002 commits therefore reduce *accessibility*, not *capability*: tip containment is hygiene, not a security boundary (Claude's assessment, adopted verbatim). **Residual, stated honestly: the exact one-line activation change remains visible on all three current tips** — inside the superseded historical protocol documents (`execution_protocol_v1.md` §13, under VOID/PROHIBITED notices), in the hold-doc hash tables, and in the manifest header comments. Task 03 removed the flag-bearing files; it did **not** remove every reactivation instruction, and this report makes no such claim. The VOID/PROHIBITED notices are documentation, not enforcement. Residual risk: anyone with repository read access can recover the configured generator from history and apply the one-line flip, guided by instructions that remain on the tips. The only currently external gate is GitHub environment reviewer approval on the generation workflow — which does not cover source-level constants and whose reviewer account overlaps the agent accounts. The durable design (authorization from an owner-controlled environment secret/variable, dispatch-time GO and protocol-hash checks, no in-package authorization constant) is **deferred to separate panel review before any implementation** (Claude plan step 4). No bank generation is authorized: GO `LC518-GO-2026-11-03-01` remains consumed by run `41591572358` and authorizes nothing further. The scientific question remains untouched: no solver construction or execution; target definition and feasibility come first.

### 8.6 Task-03 patch files

| Patch (under `patches\`) | Applies clean to | SHA-256 |
|---|---|---|
| `master\0002-LC518-containment-Task-03-remove-configured-state-1-.patch` | `82b666e` (0001 tip) | `42b6b89fc26df8bc60b896e9e76e33dad4123abf30e55d010b1e4abd060478ed` |
| `foued2-patch-1\0002-LC518-containment-Task-03-remove-configured-state-1-.patch` | `59ae815` (0001 tip) | `69c6c19ee3f2c1480b2c3169ecb435b5848c0df083f4b95d6cd05f8b5769c03b` |
| `recovery\0002-LC518-containment-Task-03-remove-configured-state-1-.patch` | `7921e35` (0001 tip) | `937a4a1ebf79acee8066a748142e3f02077bbfbe5188347e7866e0df8ba21d96` |

The r1 package (`…_2026-11-04.zip`, `0690d364…`), the 0001 patches and the r1 staging directory are preserved unchanged as the reviewed artifacts. The corrected package is `lc518_containment_review_package_2026-11-04_r2.zip` (contents: this report, 6 patches, raw-blob tree exports of the three new tips, `MANIFEST_SHA256SUMS.txt`).
