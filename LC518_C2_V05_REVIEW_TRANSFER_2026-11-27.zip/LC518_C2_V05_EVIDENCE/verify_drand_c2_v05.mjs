import { createHash } from 'node:crypto';
import { createRequire } from 'node:module';
import { readFileSync, writeFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const require = createRequire(import.meta.url);
const { HttpCachingChain, HttpChainClient, fetchBeacon, defaultChainOptions } = require('drand-client');
const { bls12_381: bls } = require('@noble/curves/bls12-381');
const here = dirname(fileURLToPath(import.meta.url));
const protocolPath = join(here, '..', 'LC518_R2_C2_SELECTION_PROTOCOL_v0.5_2026-11-27.md');
const expected = {
  beaconId: 'quicknet',
  chainHash: '52db9ba70e0cc0f6eaf7803dd07447a1f5477735fd3f661792ba94600c84e971',
  publicKey: '83cf0f2896adee7eb8b5f01fcad3912212c437e0073e911fb90022d3e760183c8c4b450b6a0a6c3ac6a5776a2d1064510d1fec758c921cc22b0e17e63aaf4bcb5ed66304de9cf809bd274ca73bab4af5a6e9c76a4bc09e76eae8991ef5ece45a',
  scheme: 'bls-unchained-g1-rfc9380',
  genesisTime: 1692803367,
  period: 3,
  round: 1,
};
const relays = [
  { id: 'relayA_api_drand_sh_v1', origin: 'https://api.drand.sh' },
  { id: 'relayB_cloudflare_v1', origin: 'https://drand.cloudflare.com' },
].map((relay) => ({
  ...relay,
  baseUrl: `${relay.origin}/${expected.chainHash}`,
  infoUrl: `${relay.origin}/${expected.chainHash}/info`,
  roundUrl: `${relay.origin}/${expected.chainHash}/public/${expected.round}`,
}));
const registryUrl = 'https://registry.npmjs.org/drand-client/1.4.2';
const registryExpected = {
  tarball: 'https://registry.npmjs.org/drand-client/-/drand-client-1.4.2.tgz',
  integrity: 'sha512-jeNJmrVplfgIA/GVndxxJ5mo8y63BS2pEdNhk1siU4pQ+z/BnxsqRnxjH9ag1ip887s12SEgo0MTZPbQNz27NA==',
  shasum: 'f9108eef6881e62c0c0f154f30f7bd0a818ea809',
};
const sha256 = (bytes) => createHash('sha256').update(bytes).digest('hex');
const sha1 = (bytes) => createHash('sha1').update(bytes).digest('hex');
const sha512Integrity = (bytes) => `sha512-${createHash('sha512').update(bytes).digest('base64')}`;
const uint256Range = 1n << 256n;
const maxUint64 = (1n << 64n) - 1n;
const selectionDomain = Buffer.from('LC518-REV11-C2-v1', 'ascii');
const nativeFetch = globalThis.fetch;
const clientHttp = [];

function selectionDigest(seedBytes, label, counter) {
  if (!Buffer.isBuffer(seedBytes) || seedBytes.length !== 32) {
    throw new Error('Synthetic or beacon seed must be exactly 32 bytes');
  }
  if (!['repeat-1', 'repeat-2'].includes(label)) {
    throw new Error(`Unknown selection label: ${label}`);
  }
  const counterValue = BigInt(counter);
  if (counterValue < 0n || counterValue > maxUint64) {
    throw new Error('Selection counter must fit in unsigned 64-bit big-endian');
  }
  const counterBytes = Buffer.alloc(8);
  counterBytes.writeBigUInt64BE(counterValue);
  const input = Buffer.concat([
    selectionDomain,
    Buffer.from([0]),
    seedBytes,
    Buffer.from([0]),
    Buffer.from(label, 'ascii'),
    Buffer.from([0]),
    counterBytes,
  ]);
  return createHash('sha256').update(input).digest();
}

function rejectionLimit(universeSize) {
  if (!Number.isInteger(universeSize) || universeSize < 1) {
    throw new Error('Selection universe size must be a positive integer');
  }
  const size = BigInt(universeSize);
  return (uint256Range / size) * size;
}

function requireDigestBelowRejectionBoundary(digestHex, universeSize) {
  if (!/^[0-9a-fA-F]{64}$/.test(digestHex)) {
    throw stageError('DIGEST_FORMAT', 'Selection digest must be exactly 32 bytes encoded as hexadecimal');
  }
  const value = BigInt(`0x${digestHex}`);
  if (value >= rejectionLimit(universeSize)) {
    throw stageError('SELECTION_REJECTION', `Digest is at or above the rejection boundary for n=${universeSize}`);
  }
  return value;
}

function deriveSelectionIndex(seedBytes, label, universeSize, digestProvider = selectionDigest) {
  const limit = rejectionLimit(universeSize);
  const rejected = [];
  for (let counter = 0n; counter <= maxUint64; counter += 1n) {
    const digest = digestProvider(seedBytes, label, counter);
    if (!Buffer.isBuffer(digest) || digest.length !== 32) {
      throw stageError('DIGEST_FORMAT', 'Selection digest provider must return exactly 32 bytes');
    }
    const value = BigInt(`0x${digest.toString('hex')}`);
    if (value >= limit) {
      rejected.push({ counter: counter.toString(), digestHex: digest.toString('hex') });
      continue;
    }
    return {
      label,
      universeSize,
      counter: counter.toString(),
      digestHex: digest.toString('hex'),
      index: Number(value % BigInt(universeSize)),
      rejected,
    };
  }
  throw new Error('Selection counter exhausted unsigned 64-bit range');
}

function selectPairIndices(seedBytes, pairUniverse, digestProvider = selectionDigest) {
  if (pairUniverse.length !== 28 || new Set(pairUniverse).size !== 28) {
    throw new Error('Selection requires the exact 28-pair universe with unique entries');
  }
  const first = deriveSelectionIndex(seedBytes, 'repeat-1', pairUniverse.length, digestProvider);
  const firstPair = pairUniverse[first.index];
  const reducedUniverse = pairUniverse.filter((pair) => pair !== firstPair);
  if (reducedUniverse.length !== 27) throw new Error('Removing the first pair must leave 27 ordered pairs');
  const second = deriveSelectionIndex(seedBytes, 'repeat-2', reducedUniverse.length, digestProvider);
  return {
    first: { ...first, pair: firstPair },
    second: { ...second, pair: reducedUniverse[second.index] },
    reducedUniverse,
  };
}

function stageError(stage, message) {
  const error = new Error(message);
  error.stage = stage;
  return error;
}

async function getRaw(url) {
  const response = await nativeFetch(url);
  return { url, status: response.status, body: await response.text() };
}

function parseJson(record) {
  if (!record || record.status < 200 || record.status >= 300) {
    throw stageError('HTTP_AND_JSON', `HTTP status ${record?.status ?? 'missing'}`);
  }
  try {
    return JSON.parse(record.body);
  } catch (error) {
    throw stageError('HTTP_AND_JSON', `JSON parse failed: ${error.message}`);
  }
}

function assertChainIdentity(rawInfo) {
  const checks = [
    { field: 'chainHash', expected: expected.chainHash, actual: rawInfo.hash },
    { field: 'publicKey', expected: expected.publicKey, actual: rawInfo.public_key },
    { field: 'scheme', expected: expected.scheme, actual: rawInfo.schemeID },
    { field: 'genesisTime', expected: expected.genesisTime, actual: rawInfo.genesis_time },
    { field: 'period', expected: expected.period, actual: rawInfo.period },
    { field: 'beaconId', expected: expected.beaconId, actual: rawInfo.metadata?.beaconID },
  ].map((check) => ({ ...check, pass: check.actual === check.expected }));
  const report = { checks, allPassed: checks.every((check) => check.pass) };
  if (!report.allPassed) {
    const failedFields = checks.filter((check) => !check.pass).map((check) => check.field).join(', ');
    throw stageError('CHAIN_IDENTITY', `Chain metadata mismatch: ${failedFields}`);
  }
  return report;
}

function makePackageClient(info, beacon) {
  const chain = { baseUrl: 'fault-fixture://quicknet', info: async () => info };
  return {
    options: {
      ...defaultChainOptions,
      disableBeaconVerification: false,
      chainVerificationParams: { chainHash: expected.chainHash, publicKey: expected.publicKey },
    },
    chain: () => chain,
    get: async (round) => {
      if (round !== beacon.round) throw new Error('unexpected fixture round');
      return beacon;
    },
    latest: async () => beacon,
  };
}

async function verifyWithPinnedPackage(info, round, signatureHex, seedHex) {
  const beacon = { round, signature: signatureHex, randomness: seedHex };
  await fetchBeacon(makePackageClient(info, beacon), round);
}

async function stagedValidate(record, rawInfo, expectedRound) {
  const payload = parseJson(record);
  assertChainIdentity(rawInfo);
  if (payload.round !== expectedRound) {
    throw stageError('ROUND_IDENTITY', `Expected round ${expectedRound}, got ${payload.round}`);
  }
  if (typeof payload.signature !== 'string' || !/^(?:[0-9a-fA-F]{2})+$/.test(payload.signature)) {
    throw stageError('SIGNATURE_HEX', 'Signature is not non-empty, even-length hexadecimal');
  }
  const signatureBytes = Buffer.from(payload.signature, 'hex');
  if (signatureBytes.length !== 48) {
    throw stageError('SIGNATURE_FORMAT', `Quicknet signature must be 48 bytes, got ${signatureBytes.length}`);
  }
  try {
    bls.G1.ProjectivePoint.fromHex(payload.signature);
  } catch (error) {
    throw stageError('SIGNATURE_FORMAT', `Signature is not a valid compressed G1 point: ${error.message}`);
  }
  const derivedSeed = sha256(signatureBytes);
  try {
    await verifyWithPinnedPackage(rawInfo, payload.round, signatureBytes.toString('hex'), derivedSeed);
  } catch (error) {
    throw stageError('BLS_VERIFICATION', `Pinned client rejected the signature: ${error.message}`);
  }
  if (Object.hasOwn(payload, 'randomness')) {
    if (typeof payload.randomness !== 'string' || !/^[0-9a-fA-F]{64}$/.test(payload.randomness) ||
        !Buffer.from(payload.randomness, 'hex').equals(Buffer.from(derivedSeed, 'hex'))) {
      throw stageError('RANDOMNESS_CONSISTENCY', 'Supplied randomness is malformed or differs from SHA-256(signature bytes)');
    }
  }
  return {
    round: payload.round,
    signatureHex: signatureBytes.toString('hex'),
    seedHex: derivedSeed,
    suppliedRandomness: Object.hasOwn(payload, 'randomness') ? payload.randomness : null,
  };
}

function compareRelays(left, right) {
  if (left.round !== right.round || left.signatureHex !== right.signatureHex || left.seedHex !== right.seedHex) {
    throw stageError('RELAY_AGREEMENT', 'Verified relay results differ in round, signature bytes, or derived seed');
  }
  return true;
}

async function expectedStage(name, expectedStageName, fn) {
  try {
    await fn();
    return { name, expectedStage: expectedStageName, actualStage: 'ACCEPTED', pass: false };
  } catch (error) {
    return {
      name,
      expectedStage: expectedStageName,
      actualStage: error.stage ?? 'UNCLASSIFIED',
      error: error.message,
      pass: error.stage === expectedStageName,
    };
  }
}

async function runNativeRelay(relay) {
  const options = {
    ...defaultChainOptions,
    disableBeaconVerification: false,
    chainVerificationParams: { chainHash: expected.chainHash, publicKey: expected.publicKey },
  };
  const chain = new HttpCachingChain(relay.baseUrl, options);
  const client = new HttpChainClient(chain, options);
  const priorFetch = globalThis.fetch;
  let rawInfo;
  let clientBeacon;
  let preFetchChainIdentity;
  globalThis.fetch = async (input, init) => {
    const requestUrl = typeof input === 'string' ? input : input.url;
    const response = await priorFetch(input, init);
    clientHttp.push({
      relay: relay.id,
      requestUrl,
      status: response.status,
      rawBody: await response.clone().text(),
    });
    return response;
  };
  try {
    rawInfo = await chain.info();
    preFetchChainIdentity = assertChainIdentity(rawInfo);
    clientBeacon = await fetchBeacon(client, expected.round);
  } finally {
    globalThis.fetch = priorFetch;
  }

  if (clientBeacon.round !== expected.round) {
    throw stageError('ROUND_IDENTITY', `${relay.id} native client returned round ${clientBeacon.round}`);
  }
  const requests = clientHttp.filter((entry) => entry.relay === relay.id);
  const infoRequest = requests.find((entry) => new URL(entry.requestUrl).pathname === `/${expected.chainHash}/info`);
  const beaconRequest = requests.find((entry) => new URL(entry.requestUrl).pathname === `/${expected.chainHash}/public/${expected.round}`);
  if (!infoRequest || !beaconRequest) {
    throw new Error(`${relay.id} did not use both expected native v1 paths /info and /public/${expected.round}`);
  }
  const infoPayload = parseJson({ status: infoRequest.status, body: infoRequest.rawBody });
  const capturedInfoIdentity = assertChainIdentity(infoPayload);
  if (!capturedInfoIdentity.allPassed) throw new Error(`${relay.id} captured chain metadata did not pass identity checks`);
  const beaconPayload = parseJson({ status: beaconRequest.status, body: beaconRequest.rawBody });
  const stagedResult = await stagedValidate({ status: beaconRequest.status, body: beaconRequest.rawBody }, infoPayload, expected.round);
  const clientSignatureHex = Buffer.from(clientBeacon.signature, 'hex').toString('hex');
  const clientSeedHex = sha256(Buffer.from(clientSignatureHex, 'hex'));
  if (clientSignatureHex !== stagedResult.signatureHex ||
      clientSeedHex !== stagedResult.seedHex ||
      clientBeacon.randomness?.toLowerCase() !== clientSeedHex ||
      (Object.hasOwn(beaconPayload, 'randomness') &&
       !Buffer.from(beaconPayload.randomness, 'hex').equals(Buffer.from(clientSeedHex, 'hex')))) {
    throw new Error(`${relay.id} native result differed from its raw response or locally derived seed`);
  }
  return {
    relay: relay.id,
    baseUrl: relay.baseUrl,
    metadataUrl: relay.infoUrl,
    beaconUrl: relay.roundUrl,
    clientImplementation: 'HttpCachingChain + HttpChainClient + fetchBeacon from drand-client@1.4.2',
    nativeBeaconVerificationEnabled: options.disableBeaconVerification === false,
    nativeClientVerified: true,
    chainIdentity: preFetchChainIdentity,
    rawInfo,
    rawInfoRequest: infoRequest,
    rawBeaconRequest: beaconRequest,
    rawBeacon: beaconPayload,
    clientBeacon: {
      round: clientBeacon.round,
      signature: clientBeacon.signature,
      randomness: clientBeacon.randomness,
    },
    normalized: stagedResult,
    localSeedMatchesWireRandomness: Object.hasOwn(beaconPayload, 'randomness') &&
      Buffer.from(beaconPayload.randomness, 'hex').equals(Buffer.from(clientSeedHex, 'hex')),
  };
}

async function main() {
  const registryRecord = await getRaw(registryUrl);
  const registry = parseJson(registryRecord);
  if (registry.name !== 'drand-client' || registry.version !== '1.4.2' ||
      registry.dist.tarball !== registryExpected.tarball ||
      registry.dist.integrity !== registryExpected.integrity ||
      registry.dist.shasum !== registryExpected.shasum) {
    throw new Error('npm registry package identity or integrity metadata did not match the pinned values');
  }

  const packageJson = require(join(here, 'node_modules', 'drand-client', 'package.json'));
  const packageExports = require('drand-client');
  const packageLockBytes = readFileSync(join(here, 'package-lock.json'));
  const packageLock = JSON.parse(packageLockBytes.toString('utf8'));
  const packageJsonBytes = readFileSync(join(here, 'package.json'));
  const tarballBytes = readFileSync(join(here, 'drand-client-1.4.2.tgz'));
  const tarballHashes = {
    bytes: tarballBytes.length,
    sha256: sha256(tarballBytes),
    sha1: sha1(tarballBytes),
    sha512Integrity: sha512Integrity(tarballBytes),
  };
  if (tarballHashes.sha1 !== registryExpected.shasum ||
      tarballHashes.sha512Integrity !== registryExpected.integrity ||
      packageJson.version !== '1.4.2' ||
      packageLock.packages['node_modules/drand-client']?.version !== '1.4.2' ||
      packageLock.packages['node_modules/@noble/curves']?.version !== '1.9.7') {
    throw new Error('Tarball, installed package, or lockfile failed the pinned identity check');
  }
  for (const exportName of ['HttpCachingChain', 'HttpChainClient', 'fetchBeacon']) {
    if (typeof packageExports[exportName] !== 'function') {
      throw new Error(`Pinned package is missing required native v1 export ${exportName}`);
    }
  }
  const httpClientSource = readFileSync(join(here, 'node_modules', 'drand-client', 'lib', 'http-chain-client.ts'), 'utf8');
  const cachingChainSource = readFileSync(join(here, 'node_modules', 'drand-client', 'lib', 'http-caching-chain.ts'), 'utf8');
  const indexSource = readFileSync(join(here, 'node_modules', 'drand-client', 'lib', 'index.ts'), 'utf8');
  if (!httpClientSource.includes('/public/${roundNumber}') ||
      !cachingChainSource.includes('${this.baseUrl}/info') ||
      /apiVersion|\/v2\/beacons/.test(httpClientSource + cachingChainSource + indexSource)) {
    throw new Error('Installed v1.4.2 sources did not match the pinned legacy-v1 transport expectation');
  }

  const lockPackages = Object.entries(packageLock.packages)
    .filter(([name]) => name.startsWith('node_modules/'))
    .map(([name, value]) => ({ name, version: value.version, resolved: value.resolved ?? null, integrity: value.integrity ?? null }))
    .sort((a, b) => a.name.localeCompare(b.name));
  const relayResults = [];
  for (const relay of relays) relayResults.push(await runNativeRelay(relay));
  compareRelays(relayResults[0].normalized, relayResults[1].normalized);

  const basePayload = relayResults[0].rawBeacon;
  const baseInfo = relayResults[0].rawInfo;
  const baseRecord = { status: 200, body: JSON.stringify(basePayload) };
  const baseNormalized = relayResults[0].normalized;
  const modifiedSignaturePoint = bls.G1.ProjectivePoint.fromHex(basePayload.signature).add(bls.G1.ProjectivePoint.BASE);
  const tamperedSignature = modifiedSignaturePoint.toHex(true);
  const tamperedBytes = Buffer.from(tamperedSignature, 'hex');
  const tamperedSeed = sha256(tamperedBytes);
  const tamperedPayload = { ...basePayload, signature: tamperedSignature, randomness: tamperedSeed };
  const wrongRandomnessPayload = { ...basePayload, randomness: '00'.repeat(32) };
  const wrongHashInfo = { ...baseInfo, hash: '00'.repeat(32) };
  const wrongKeyInfo = { ...baseInfo, public_key: '00'.repeat(96) };
  const wrongSchemeInfo = { ...baseInfo, schemeID: 'wrong-scheme' };
  const wrongGenesisTimeInfo = { ...baseInfo, genesis_time: baseInfo.genesis_time + 1 };
  const wrongPeriodInfo = { ...baseInfo, period: baseInfo.period + 1 };
  const wrongBeaconIdInfo = { ...baseInfo, metadata: { ...baseInfo.metadata, beaconID: 'wrong-beacon' } };
  const wrongRoundPayload = { ...basePayload, round: expected.round + 1 };
  const malformedHexPayload = { ...basePayload, signature: 'zz' };
  const shortHexPayload = { ...basePayload, signature: 'aabb' };
  const negativeTests = [];
  negativeTests.push(await expectedStage('HTTP non-2xx', 'HTTP_AND_JSON', () => stagedValidate({ status: 503, body: '{}' }, baseInfo, expected.round)));
  negativeTests.push(await expectedStage('Malformed JSON', 'HTTP_AND_JSON', () => stagedValidate({ status: 200, body: '{' }, baseInfo, expected.round)));
  negativeTests.push(await expectedStage('Wrong chain hash', 'CHAIN_IDENTITY', () => stagedValidate(baseRecord, wrongHashInfo, expected.round)));
  negativeTests.push(await expectedStage('Wrong public key', 'CHAIN_IDENTITY', () => stagedValidate(baseRecord, wrongKeyInfo, expected.round)));
  negativeTests.push(await expectedStage('Wrong scheme', 'CHAIN_IDENTITY', () => stagedValidate(baseRecord, wrongSchemeInfo, expected.round)));
  negativeTests.push(await expectedStage('Wrong genesis time', 'CHAIN_IDENTITY', () => stagedValidate(baseRecord, wrongGenesisTimeInfo, expected.round)));
  negativeTests.push(await expectedStage('Wrong period', 'CHAIN_IDENTITY', () => stagedValidate(baseRecord, wrongPeriodInfo, expected.round)));
  negativeTests.push(await expectedStage('Wrong beacon ID', 'CHAIN_IDENTITY', () => stagedValidate(baseRecord, wrongBeaconIdInfo, expected.round)));
  negativeTests.push(await expectedStage('Wrong round', 'ROUND_IDENTITY', () => stagedValidate({ status: 200, body: JSON.stringify(wrongRoundPayload) }, baseInfo, expected.round)));
  negativeTests.push(await expectedStage('Malformed signature hex', 'SIGNATURE_HEX', () => stagedValidate({ status: 200, body: JSON.stringify(malformedHexPayload) }, baseInfo, expected.round)));
  negativeTests.push(await expectedStage('Decodable wrong signature length', 'SIGNATURE_FORMAT', () => stagedValidate({ status: 200, body: JSON.stringify(shortHexPayload) }, baseInfo, expected.round)));
  negativeTests.push(await expectedStage('Tampered signature with recomputed randomness', 'BLS_VERIFICATION', () => stagedValidate({ status: 200, body: JSON.stringify(tamperedPayload) }, baseInfo, expected.round)));
  negativeTests.push(await expectedStage('Valid signature with wrong v1 randomness', 'RANDOMNESS_CONSISTENCY', () => stagedValidate({ status: 200, body: JSON.stringify(wrongRandomnessPayload) }, baseInfo, expected.round)));
  if (!negativeTests.every((test) => test.pass)) throw new Error('One or more negative tests rejected at the wrong stage');

  let d1;
  try {
    await stagedValidate(baseRecord, baseInfo, expected.round);
    await stagedValidate({ status: 200, body: JSON.stringify(tamperedPayload) }, relayResults[1].rawInfo, expected.round);
    compareRelays(baseNormalized, { ...baseNormalized, signatureHex: tamperedSignature, seedHex: tamperedSeed });
    d1 = { pass: false, actualStage: 'ACCEPTED' };
  } catch (error) {
    d1 = { pass: error.stage === 'BLS_VERIFICATION', actualStage: error.stage ?? 'UNCLASSIFIED', error: error.message };
  }
  if (!d1.pass) throw new Error('D1 did not abort at BLS_VERIFICATION before relay agreement');

  const faultInjectedVerifiedA = { ...baseNormalized, fixtureLabel: 'FAULT_INJECTED_AS_VERIFIED_A' };
  const faultInjectedVerifiedB = {
    ...baseNormalized,
    signatureHex: tamperedSignature,
    seedHex: tamperedSeed,
    suppliedRandomness: tamperedSeed,
    fixtureLabel: 'FAULT_INJECTED_AS_VERIFIED_B_NOT_CRYPTOGRAPHICALLY_REVERIFIED',
  };
  let d2;
  try {
    compareRelays(faultInjectedVerifiedA, faultInjectedVerifiedB);
    d2 = { pass: false, actualStage: 'ACCEPTED' };
  } catch (error) {
    d2 = { pass: error.stage === 'RELAY_AGREEMENT', actualStage: error.stage ?? 'UNCLASSIFIED', error: error.message };
  }
  if (!d2.pass) throw new Error('D2 comparator did not reject at RELAY_AGREEMENT');

  const maxAcceptedDigest = (uint256Range - 17n).toString(16).padStart(64, '0');
  const firstRejectedDigest = (uint256Range - 16n).toString(16).padStart(64, '0');
  const maxUint256Digest = (uint256Range - 1n).toString(16).padStart(64, '0');
  const boundaryTests = [];
  for (const universeSize of [28, 27]) {
    boundaryTests.push({
      name: `n=${universeSize} maximum accepted digest`,
      expected: 'ACCEPTED_BELOW_BOUNDARY',
      actual: (() => { requireDigestBelowRejectionBoundary(maxAcceptedDigest, universeSize); return 'ACCEPTED_BELOW_BOUNDARY'; })(),
    });
    boundaryTests.push(expectedStage(
      `n=${universeSize} digest equal to first rejected value`,
      'SELECTION_REJECTION',
      () => requireDigestBelowRejectionBoundary(firstRejectedDigest, universeSize),
    ));
    boundaryTests.push(expectedStage(
      `n=${universeSize} maximum 256-bit digest`,
      'SELECTION_REJECTION',
      () => requireDigestBelowRejectionBoundary(maxUint256Digest, universeSize),
    ));
  }
  const resolvedBoundaryTests = await Promise.all(boundaryTests);
  if (!resolvedBoundaryTests.every((test) => test.pass ?? test.actual === test.expected)) {
    throw new Error('Selection-digest rejection-boundary fixture failed');
  }

  const pairUniverseLines = [];
  for (let left = 1; left <= 8; left += 1) {
    for (let right = left + 1; right <= 8; right += 1) {
      pairUniverseLines.push(`M${String(left).padStart(2, '0')}/M${String(right).padStart(2, '0')}`);
    }
  }
  const pairUniverseBytes = Buffer.from(`${pairUniverseLines.join('\n')}\n`, 'utf8');
  const pairUniverseSha256 = sha256(pairUniverseBytes);
  if (pairUniverseLines.length !== 28 || pairUniverseBytes.length !== 224 ||
      pairUniverseSha256 !== 'd5e54cd8a071fde1fd06a897b611fb9d39bfa28f5aeecb06e46537a2f93149bd') {
    throw new Error('Canonical pair-universe serialization check failed');
  }
  const digestVectors = [
    { name: 'empty byte string', input: '', expected: 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855' },
    { name: 'abc', input: 'abc', expected: 'ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad' },
    { name: 'hello', input: 'hello', expected: '2cf24dba5fb0a30e26e83b2ac5b9e29e1b161e5c1fa7425e73043362938b9824' },
    { name: 'quick brown fox', input: 'The quick brown fox jumps over the lazy dog', expected: 'd7a8fbb307d7809469ca9abcb0082e4f8d5651e46d3cdb762d02d0bf37c9e592' },
  ].map((vector) => ({
    name: vector.name,
    input: vector.input,
    expected: vector.expected,
    actual: sha256(Buffer.from(vector.input, 'utf8')),
    pass: sha256(Buffer.from(vector.input, 'utf8')) === vector.expected,
  }));
  if (!digestVectors.every((vector) => vector.pass)) throw new Error('SHA-256 regression vector failed');

  const syntheticSeedHex = '000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f';
  const syntheticSeed = Buffer.from(syntheticSeedHex, 'hex');
  const selectionDigestVectors = [
    { label: 'repeat-1', counter: 0, universeSize: 28, expectedIndex: 5, prefix: '996627683d5bd28b', suffix: 'f659' },
    { label: 'repeat-1', counter: 1, universeSize: 28, expectedIndex: 23, prefix: 'c59aff206cf93ecd', suffix: '0ddb' },
    { label: 'repeat-2', counter: 0, universeSize: 27, expectedIndex: 19, prefix: 'bce13a787bba4cf2', suffix: '4881' },
    { label: 'repeat-2', counter: 1, universeSize: 27, expectedIndex: 13, prefix: '8f096ae539624f40', suffix: '3561' },
  ].map((vector) => {
    const digestHex = selectionDigest(syntheticSeed, vector.label, BigInt(vector.counter)).toString('hex');
    const index = Number(BigInt(`0x${digestHex}`) % BigInt(vector.universeSize));
    return {
      ...vector,
      digestHex,
      index,
      pass: digestHex.startsWith(vector.prefix) && digestHex.endsWith(vector.suffix) && index === vector.expectedIndex,
    };
  });
  const syntheticSelection = selectPairIndices(syntheticSeed, pairUniverseLines);
  const expectedSyntheticPairs = ['M01/M07', 'M04/M07'];
  const syntheticSelectionConformance = {
    seedHex: syntheticSeedHex,
    digestDomain: 'LC518-REV11-C2-v1',
    counterEncoding: 'uint64 big-endian',
    digestVectors: selectionDigestVectors,
    selectedPairs: [syntheticSelection.first.pair, syntheticSelection.second.pair],
    drawDetails: [syntheticSelection.first, syntheticSelection.second],
    expectedPairs: expectedSyntheticPairs,
    passed: selectionDigestVectors.every((vector) => vector.pass) &&
      syntheticSelection.first.counter === '0' && syntheticSelection.second.counter === '0' &&
      JSON.stringify([syntheticSelection.first.pair, syntheticSelection.second.pair]) === JSON.stringify(expectedSyntheticPairs),
    scope: 'synthetic conformance fixture only; not a drand draw or production selection',
  };
  if (!syntheticSelectionConformance.passed) {
    throw new Error('Fixed-seed selection conformance fixture failed');
  }

  const injectedRejectionTests = [
    { label: 'repeat-1', universeSize: 28, expectedIndex: 23 },
    { label: 'repeat-2', universeSize: 27, expectedIndex: 13 },
  ].map((test) => {
    const requestedCounters = [];
    const result = deriveSelectionIndex(syntheticSeed, test.label, test.universeSize, (seedBytes, label, counter) => {
      requestedCounters.push(counter.toString());
      return counter === 0n ? Buffer.from(firstRejectedDigest, 'hex') : selectionDigest(seedBytes, label, counter);
    });
    return {
      ...test,
      injectedCounterZeroDigest: firstRejectedDigest,
      requestedCounters,
      actualCounter: result.counter,
      actualDigestHex: result.digestHex,
      actualIndex: result.index,
      rejectionCount: result.rejected.length,
      pass: requestedCounters.join(',') === '0,1' && result.counter === '1' &&
        result.index === test.expectedIndex && result.rejected.length === 1,
    };
  });
  if (!injectedRejectionTests.every((test) => test.pass)) {
    throw new Error('Injected selection rejection/counter-increment fixture failed');
  }

  const sourceHashes = {
    httpChainClientSha256: sha256(Buffer.from(httpClientSource, 'utf8')),
    httpCachingChainSha256: sha256(Buffer.from(cachingChainSource, 'utf8')),
    indexSha256: sha256(Buffer.from(indexSource, 'utf8')),
  };
  const protocolBytes = readFileSync(protocolPath);
  const verifierBytes = readFileSync(fileURLToPath(import.meta.url));
  const evidence = {
    status: 'BOUNDED_HISTORICAL_AND_FIXTURE_CHECKS_ONLY; NO_DRAW',
    generatedUtc: new Date().toISOString(),
    runtime: { node: process.version, platform: process.platform, arch: process.arch },
    fixedRound: expected.round,
    pinnedChain: expected,
    forbiddenActions: {
      requestedNewBeaconRound: false,
      queriedStoppedRound34323983: false,
      calculatedProductionSeedRank: false,
      selectedProductionPairs: false,
      calculatedSyntheticFixtureIndices: true,
      mappedSyntheticFixturePairs: true,
      constructedOrExecutedSolvers: false,
    },
    package: {
      name: packageJson.name,
      version: packageJson.version,
      exports: Object.keys(packageExports).sort(),
      requiredNativeV1ExportsPresent: true,
      nativeV2AdapterUsed: false,
      disableBeaconVerification: false,
      sourceFiles: sourceHashes,
      sourceChecks: {
        getUsesLegacyPublicPath: httpClientSource.includes('/public/${roundNumber}'),
        infoUsesLegacyInfoPath: cachingChainSource.includes('${this.baseUrl}/info'),
        noApiVersionOrV2TransportInPinnedSource: !/apiVersion|\/v2\/beacons/.test(httpClientSource + cachingChainSource + indexSource),
      },
      dependencyVersionsFromLock: lockPackages,
      packageJson: { path: 'package.json', bytes: packageJsonBytes.length, sha256: sha256(packageJsonBytes) },
      packageLock: { path: 'package-lock.json', bytes: packageLockBytes.length, sha256: sha256(packageLockBytes) },
      tarball: { path: 'drand-client-1.4.2.tgz', ...tarballHashes },
      npmRegistry: {
        url: registryUrl,
        httpStatus: registryRecord.status,
        responseSha256: sha256(Buffer.from(registryRecord.body, 'utf8')),
        name: registry.name,
        version: registry.version,
        tarball: registry.dist.tarball,
        integrity: registry.dist.integrity,
        shasum: registry.dist.shasum,
        dependencies: registry.dependencies,
        exactBody: registryRecord.body,
      },
    },
    protocol: { path: 'reviews/LC518_R2_C2_SELECTION_PROTOCOL_v0.5_2026-11-27.md', bytes: protocolBytes.length, sha256: sha256(protocolBytes) },
    verifier: { path: 'reviews/LC518_C2_V05_EVIDENCE/verify_drand_c2_v05.mjs', bytes: verifierBytes.length, sha256: sha256(verifierBytes) },
    relays: relayResults,
    chainIdentityChecks: relayResults.map(({ relay, chainIdentity }) => ({ relay, ...chainIdentity })),
    relayAgreement: {
      sameRound: relayResults[0].normalized.round === relayResults[1].normalized.round,
      sameSignatureBytes: relayResults[0].normalized.signatureHex === relayResults[1].normalized.signatureHex,
      sameLocallyDerivedSeed: relayResults[0].normalized.seedHex === relayResults[1].normalized.seedHex,
      bothNativeClientsVerified: relayResults.every((relay) => relay.nativeClientVerified),
      passed: true,
    },
    negativeTests,
    relayDisagreementTests: {
      D1_fullWorkflow: { ...d1, relayA: 'native v1 fixed historical round 1', relayB: 'fault-injected different valid-format signature with recomputed randomness; must fail BLS before comparator' },
      D2_comparator: { ...d2, inputs: [faultInjectedVerifiedA, faultInjectedVerifiedB], note: 'Injected comparator objects are not represented as two cryptographically valid signatures.' },
    },
    selectionIntegrity: {
      pairUniverse: { pairCount: pairUniverseLines.length, byteLength: pairUniverseBytes.length, sha256: pairUniverseSha256 },
      sha256RegressionVectors: {
        tests: digestVectors,
        allPassed: digestVectors.every((vector) => vector.pass),
        note: 'These vectors check the SHA-256 primitive only; the fixed synthetic selection conformance fixture separately checks the selection framing and mapping.',
      },
      syntheticSelectionConformance,
      injectedRejectionTests,
      rejectionBoundary: {
        universeSizes: [28, 27],
        maxAcceptedDigestHex: maxAcceptedDigest,
        firstRejectedDigestHex: firstRejectedDigest,
        tests: resolvedBoundaryTests,
        noProductionRankOrPairIdentitiesCalculated: true,
      },
    },
    stoppedAttempt34323983: {
      historicalRecord: 'reviews/LC518_R2_C2_SELECTION_ATTEMPT_2026-11-27.md',
      disposition: 'permanently excluded; not queried or reused by this v0.5 verification',
    },
  };
  const output = {
    status: evidence.status,
    packageVersion: packageJson.version,
    nativeClients: relayResults.map(({ relay, nativeClientVerified, normalized, metadataUrl, beaconUrl, chainIdentity }) => ({ relay, nativeClientVerified, round: normalized.round, signatureHex: normalized.signatureHex, locallyDerivedSeed: normalized.seedHex, metadataUrl, beaconUrl, chainIdentity })),
    chainIdentityChecks: evidence.chainIdentityChecks,
    relayAgreement: evidence.relayAgreement,
    negativeTestStages: negativeTests.map(({ name, expectedStage, actualStage, pass }) => ({ name, expectedStage, actualStage, pass })),
    D1: d1,
    D2: d2,
    pairUniverseSha256,
    digestVectors,
    syntheticSelectionConformance,
    injectedRejectionTests,
    selectionBoundaryTests: resolvedBoundaryTests,
    artifactHashes: {
      protocolSha256: evidence.protocol.sha256,
      verifierSha256: evidence.verifier.sha256,
      packageJsonSha256: evidence.package.packageJson.sha256,
      packageLockSha256: evidence.package.packageLock.sha256,
      tarballSha256: tarballHashes.sha256,
    },
    evidenceFile: 'reviews/LC518_C2_V05_EVIDENCE/run-evidence.json',
  };
  writeFileSync(join(here, 'npm-metadata.json'), registryRecord.body, 'utf8');
  writeFileSync(join(here, 'run-evidence.json'), JSON.stringify(evidence, null, 2) + '\n', 'utf8');
  writeFileSync(join(here, 'RUN_OUTPUT.txt'), JSON.stringify(output, null, 2) + '\n', 'utf8');
  console.log(JSON.stringify(output, null, 2));
}

main().catch((error) => {
  console.error(error.stack ?? error.message);
  process.exitCode = 1;
});
