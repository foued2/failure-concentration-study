# C2 selection protocol v0.5 verification evidence

**Status:** bounded historical-round and fixture verification only; no production draw, rank calculation, production pair selection, or solver activity. The v0.5 protocol remains a draft and is not approved or locked. Synthetic fixture pair labels are computed below only to test the fixed conformance vector.

## Purpose and result

This evidence supports `LC518_R2_C2_SELECTION_PROTOCOL_v0.5_2026-11-27.md`. It uses the exact `drand-client@1.4.2` npm artifact with separate native v1 client instances at `api.drand.sh` and `drand.cloudflare.com`. These are independent relay-origin checks for the same signed drand beacon, not independent randomness or entropy sources. Each client used its own `HttpCachingChain` and `HttpChainClient`, with beacon verification enabled and the same pinned chain parameters.

Both clients accepted round 1 and returned identical signature bytes:

`b55e7cb2d5c613ee0b2e28d6750aabbb78c39dcc96bd9d38c2c2e12198df95571de8e8e402a0cc48871c7089a2b3af4b`

The independently derived SHA-256 seed was identical for both:

`1466a6cd24e327188770752f6134001c64d6efcc590ccc26b721611ad96f165a`

Both relays passed field-by-field checks of the chain hash, public key, scheme, genesis time, period, and beacon ID before the fixed historical beacon request. The nine original rejection-stage fixtures and four added metadata-mutation fixtures passed. D1 aborted at `BLS_VERIFICATION`; D2 rejected the fault-injected result pair at `RELAY_AGREEMENT`. The 28-pair universe hash passed. The fixed synthetic seed fixture passed all four supplied label/counter index vectors (`5, 23, 19, 13`) and mapped counter-0 draws to `M01/M07`, then `M04/M07` after removing the first pair while preserving the order of the remaining pairs. Injected `...fff0` digests were rejected at counter 0 and accepted at counter 1 for both `n=28` and `n=27`; direct boundary tests also passed for both sizes. This synthetic conformance test calculates only its specified fixture pair labels, not a production selection.

Per the owner's disposition, the authoritative mapping is locked v0.3 §§7–8; v0.4's single-seed `R mod 378` mapping is superseded. The v0.5 draft now spells out the domain-separated hash framing, counter encoding, rejection rule, reduced-universe order, and synthetic test. The exact v0.3 source file and hash are not present in this checkout, so its byte identity has not been independently authenticated here. The separately unavailable historical selection-digest input remains unavailable and unreconstructed.

The v0.4 protocol, verifier, results, and adapter remain separate historical evidence; its mapping is not operative, and its adapter is not used or described as native v2 support. Round `34323983` was not queried or reused. No drand-derived production rank or pair selection was calculated; the only pair labels calculated are the fixed synthetic conformance outputs above.

## Reproduction

Run from the repository root in PowerShell:

```powershell
npm ci --ignore-scripts --no-audit --no-fund --prefix 'reviews\LC518_C2_V05_EVIDENCE'
npm ls --depth=0 --prefix 'reviews\LC518_C2_V05_EVIDENCE'
node --check 'reviews\LC518_C2_V05_EVIDENCE\verify_drand_c2_v05.mjs'
node 'reviews\LC518_C2_V05_EVIDENCE\verify_drand_c2_v05.mjs'
```

Each command completed with exit code `0` in the recorded verification. `npm ci` installed 13 packages; `npm ls` confirmed `drand-client@1.4.2` and `@noble/curves@1.9.7`. The verifier makes bounded live requests for the fixed historical round and writes `run-evidence.json`, `RUN_OUTPUT.txt`, and `npm-metadata.json` in this directory. The JSON evidence retains raw client request URLs, statuses and response bodies, package/source identities, and fixture results.

## Artifact identities

The complete protocol, verifier, package, lock, tarball and runtime identity values are in `run-evidence.json`. These SHA-256 values identify the protocol and inputs used by the final recorded verifier run.

- Protocol: `3fe16b05d31f1f45fa32afa7a5dc6f888055cc8f5e7bd4407dbf91d19a1d7d57`
- Verifier: `2483027442339db0cc5cdd246f160c24a38bf86ab57842a88c4b598b6304068f`
- `package.json`: `52776a256bc14ab214603d0956ffd1604aad724fdf120ea5bea801309006d147`
- `package-lock.json`: `e32581489563ea4fcacf8779164e1c4bc53dc4e24a5bbb309ff9fb25a913d827`
- `drand-client-1.4.2.tgz`: `81de34afba38520b461152bf032cfb5139bb6ced205bf9f50bc8216fdc394eef`

The installed direct versions are `drand-client@1.4.2` and `@noble/curves@1.9.7`; `npm ls --depth=0` completed successfully. The archived package's registry SHA-1 and SHA-512 integrity values are recorded in `run-evidence.json`.

SHA-256 of the generated outputs from the recorded run (these can differ on a later live run):

- `run-evidence.json` (35,486 bytes): `de4083b0d62c05f0db3b154183a9b7c19484fdbb06cf8b013db6fb45fe72dc2a`
- `RUN_OUTPUT.txt` (15,934 bytes): `c01b493285b4de82fe5aa1a61bab54168c0caea8bd90ff5ed9c57a09af701bf6`
- `npm-metadata.json` (3,125 bytes): `c39a7bc2b282e6e513a50f5ce9a8e41d7cdfc4f5276d28a35acd69565c8aa5af`

## Limits and authorization

This validates only the pinned client integration and the specified historical/fixture behavior. It does not approve or lock the v0.5 draft, validate the unavailable historical selection-digest input, authorize a new beacon round, determine a production random rank or pair, establish R2 adoption/C2 compliance, or authorize construction or execution.
