# LC518 Rev11 C2 Replacement Selection Protocol v0.5 — Draft

**Status: DRAFT. NOT APPROVED. NOT LOCKED. NO DRAW AUTHORIZED.**  
**Date:** 2026-11-27  
**Predecessor:** `reviews/LC518_R2_C2_SELECTION_PROTOCOL_v0.4_2026-11-27.md` (SHA-256 `a3364c000927392bf55a01c4964c726f050e27e19a6044dde0e5b301a79185`)  
**Stopped attempt:** `reviews/LC518_R2_C2_SELECTION_ATTEMPT_2026-11-27.md`; round `34323983` is permanently excluded from any replacement attempt.  
**R2 input candidate:** `LC518_A2_FRESH_PRIVATE_CANDIDATE_v0.2.1_2026-11-25_REVIEW_R2.zip`, SHA-256 `c0f3d4184397238d295da790abe7bfc1ba1a49828a8accea21f1a56e03521da7`.

This draft revises the bounded client-verification procedure and corrects the candidate text to carry forward the selection mapping identified as authoritative in locked v0.3 §§7–8. It does not amend that locked mapping, adopt R2, authorize a draw, construct parent sources, execute solvers, or authorize publication. The historical v0.4 draft, verifier, and results are preserved unchanged as prior evidence.

## 1. Revision history and client-version correction

- **v0.2:** contained incorrect hexadecimal strings for the rejection-sampling boundary.
- **Locked v0.3 mapping:** per the owner's disposition, v0.3 §§7–8 define two domain-separated SHA-256 draws: `repeat-1` indexes the 28-pair universe, then `repeat-2` indexes the 27-pair universe after removing the first pair. For both draw sizes, `L = floor(2^256/n) × n = 2^256 − 16`; values at or above `L` are rejected and the same label's counter increments. The exact v0.3 source file/hash is not present in this checkout, so its byte identity is not independently authenticated in this record.
- **v0.4 candidate:** retained valid stage, fault-injection, boundary, and historical checks, but attempted to meet a native v2-client requirement with `drand-client@1.4.2`. Its section 4 also described a single `R mod 378` mapping, which conflicts with the locked v0.3 mapping and is superseded, not operative. The v0.4 adapter and outputs remain historical evidence only and are not represented as native v2 integration.
- **v0.5:** withdraws the incompatible native-v2 requirement, uses separate native v1.4.2 client instances (one per relay origin), and restores the locked v0.3 selection mapping in its candidate text. The two origins are independent transport-path checks for the same signed drand beacon, not independent randomness or entropy sources.
- The canonical 28-pair universe is the lexicographically ordered lines `M01/M02` through `M07/M08`, UTF-8 encoded with LF after every line (224 bytes), SHA-256 `d5e54cd8a071fde1fd06a897b611fb9d39bfa28f5aeecb06e46537a2f93149bd`.
- A prior review summary reports four selection-digest vectors yielding indices `5, 23, 19, 13`, but those vector inputs and expected digests are not present in the retained local v0.4 verifier or evidence. v0.5 does not claim to reproduce those missing selection vectors; it adds four explicit SHA-256 regression vectors for the digest primitive, recorded separately from selection mapping.

The exact npm artifact remains `drand-client@1.4.2`, registry integrity `sha512-jeNJmrVplfgIA/GVndxxJ5mo8y63BS2pEdNhk1siU4pQ+z/BnxsqRnxjH9ag1ip887s12SEgo0MTZPbQNz27NA==`, registry SHA-1 `f9108eef6881e62c0c0f154f30f7bd0a818ea809`. The v0.5 evidence directory retains its own tarball and dependency lock; no unpinned package or development-branch client is permitted.

## 2. Pinned Quicknet identity and historical relay test

The fixed chain is drand Quicknet:

- Beacon ID: `quicknet`
- Chain hash: `52db9ba70e0cc0f6eaf7803dd07447a1f5477735fd3f661792ba94600c84e971`
- Public key: `83cf0f2896adee7eb8b5f01fcad3912212c437e0073e911fb90022d3e760183c8c4b450b6a0a6c3ac6a5776a2d1064510d1fec758c921cc22b0e17e63aaf4bcb5ed66304de9cf809bd274ca73bab4af5a6e9c76a4bc09e76eae8991ef5ece45a`
- Scheme: `bls-unchained-g1-rfc9380`
- Genesis time: `1692803367`; period: `3` seconds
- Historical test round: `1` only; it is not a draw round.

Use separate native `drand-client@1.4.2` client instances with beacon verification enabled and the same pinned `chainVerificationParams`; these are independent relay-origin checks of one beacon, not independent randomness sources:

| Client | v1 base URL | Required metadata path | Required beacon path for round 1 |
|---|---|---|---|
| Relay A | `https://api.drand.sh/52db9ba70e0cc0f6eaf7803dd07447a1f5477735fd3f661792ba94600c84e971` | `/info` | `/public/1` |
| Relay B | `https://drand.cloudflare.com/52db9ba70e0cc0f6eaf7803dd07447a1f5477735fd3f661792ba94600c84e971` | `/info` | `/public/1` |

For each origin, create a separate `HttpCachingChain` and `HttpChainClient`; call `chain.info()`, explicitly compare the raw `/info` metadata against the pinned chain identity, and only then call `fetchBeacon(client, 1)`. The metadata gate must compare chain hash, public key, scheme, genesis time, period, and beacon ID before requesting the beacon. Do not normalize a v2 response into a client-shaped beacon. Capture each client's actual requests and raw HTTP response bodies for `/info` and `/public/1`. Preserve a field-by-field expected/actual/pass record for every metadata comparison and the client-returned beacon, including whether it passed the package's native verification.

For each raw v1 response, derive `seed = SHA-256(decoded signature bytes)` independently. Require the client-returned round to be `1`; require the two raw response rounds and decoded signature bytes to be identical; require the locally derived seeds to be identical; and, when the v1 response supplies `randomness`, require it to match the local seed. Any HTTP, metadata, signature, randomness, or cross-relay disagreement aborts this bounded check.

## 3. Ordered validation stages

For injected fixtures and reported raw responses, validate sequentially and retain the first rejection stage. A later check must not conceal an earlier failure.

1. **`HTTP_AND_JSON`** — successful HTTP status and syntactically valid JSON.
2. **`CHAIN_IDENTITY`** — exact equality of beacon ID, chain hash, public key, scheme, genesis time, and period against §2.
3. **`ROUND_IDENTITY`** — response round equals the fixed historical round (`1`) in this verification task, or the separately preregistered target in a future, independently authorized procedure.
4. **`SIGNATURE_HEX`** — nonempty, even-length hexadecimal signature, decoded to bytes.
5. **`SIGNATURE_FORMAT`** — valid compressed G1 encoding and exactly 48 bytes for this pinned scheme.
6. **`BLS_VERIFICATION`** — the exact pinned native `drand-client@1.4.2` verification path accepts the beacon using the pinned public key, scheme, and correct round message.
7. **`RANDOMNESS_CONSISTENCY`** — derive SHA-256 from decoded signature bytes; if a response supplies `randomness`, require 64 hexadecimal characters and exact byte equality. Record the locally derived seed independently.
8. **`RELAY_AGREEMENT`** — only after both native-client results independently pass stages 1–7, require identical round, signature bytes, and derived seed.

Retain raw request URLs, statuses, response bodies, validated metadata, first-failure stage and reason, client/package identity, and locally derived seed. Never infer a missing raw response field from a normalized client object.

## 4. Selection mapping and rejection boundary (locked v0.3 mapping; production draw not executed)

The eligible universe consists of all 28 unordered mechanism pairs from `M01` through `M08`, each pair listed once in numeric lexicographic combination order. The canonical bytes are each `Mxx/Myy` line followed by LF, with a final LF; expected byte length is 224 and SHA-256 is `d5e54cd8a071fde1fd06a897b611fb9d39bfa28f5aeecb06e46537a2f93149bd`. This is the ordered list used for both draws.

The verifier also checks the SHA-256 helper against these fixed regression vectors before any other digest result is relied upon:

| UTF-8 input | Expected SHA-256 |
|---|---|
| empty byte string | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| `abc` | `ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad` |
| `hello` | `2cf24dba5fb0a30e26e83b2ac5b9e29e1b161e5c1fa7425e73043362938b9824` |
| `The quick brown fox jumps over the lazy dog` | `d7a8fbb307d7809469ca9abcb0082e4f8d5651e46d3cdb762d02d0bf37c9e592` |

These are digest-primitive regression checks only; the fixed synthetic selection fixture below separately tests the selection framing and mapping. The unavailable historical selection-digest input remains unavailable and is not reconstructed.

For each labeled draw, construct the SHA-256 input as the exact byte concatenation:

`ASCII("LC518-REV11-C2-v1") || 0x00 || seed[32] || 0x00 || ASCII(label) || 0x00 || uint64_BE(counter)`

The prefix is 17 ASCII bytes; labels are exactly `repeat-1` and `repeat-2`; the counter is unsigned 64-bit big-endian and starts at zero. Interpret SHA-256 as an unsigned 256-bit big-endian integer `x`. For universe size `n`, set `L = floor(2^256/n) × n`; reject `x >= L`, increment that label's counter by exactly one, and recompute. Otherwise use `x mod n`. For `n = 28` and `n = 27`, `L = 2^256 − 16`, the maximum accepted digest ends in `...ffef`, and the first rejected digest is `...fff0`.

The first draw uses label `repeat-1` and `n = 28`; select the pair at that index in the full ordered universe. For the second draw, remove the first selected pair from the full list and preserve the relative order of the other 27 pairs. Use label `repeat-2` and `n = 27` to index that reduced list. This guarantees two distinct pairs without replacement. There is no reroll, alternate source, or substitution beyond the prescribed counter increment for rejection. The single-seed `R mod 378` mapping in v0.4 is superseded and must not be used.

The fixed synthetic conformance fixture is not historical drand input and is not a production selection:

- Seed bytes: `000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f`.
- Expected label/counter indices: `repeat-1/0 → 5`, `repeat-1/1 → 23`, `repeat-2/0 → 19`, and `repeat-2/1 → 13`. Counters 1 are independent vector checks; the selected pairs use counter 0 because those digests are accepted.
- Expected mapping: first `M01/M07`; remove it while preserving order; then `M04/M07`.
- The test must also inject digest `...fff0` at counter 0 for each draw and verify rejection followed by acceptance at counter 1. This injected case exercises the retry branch; it is not a claim that the real synthetic counter-0 digests are rejected.

The verifier may calculate indices and pair labels only for this fixed synthetic fixture. It must not derive or map a production selection from a drand round during bounded verification.

## 5. Required negative tests

Each test must record its fixture, expected stage, actual first-failure stage, and pass/fail result. Tests may use fixed historical data and injected fixtures only; they must not request a new beacon round.

| Fixture | Required rejection stage |
|---|---|
| HTTP non-2xx | `HTTP_AND_JSON` |
| Malformed JSON | `HTTP_AND_JSON` |
| Wrong chain hash | `CHAIN_IDENTITY` |
| Wrong public key | `CHAIN_IDENTITY` |
| Wrong scheme | `CHAIN_IDENTITY` |
| Wrong genesis time | `CHAIN_IDENTITY` |
| Wrong period | `CHAIN_IDENTITY` |
| Wrong beacon ID | `CHAIN_IDENTITY` |
| Wrong response round | `ROUND_IDENTITY` |
| Malformed hexadecimal signature | `SIGNATURE_HEX` |
| Decodable signature of invalid length/encoding | `SIGNATURE_FORMAT` |
| Tampered but correctly encoded signature with its SHA-256 randomness recomputed | `BLS_VERIFICATION` |
| Valid signature with deliberately incorrect supplied v1 randomness | `RANDOMNESS_CONSISTENCY` |
| Selection digest equal to or above `L` | Reject that digest, increment the same label's counter, and recompute before pair indexing |

The BLS-negative fixture must pass all prior checks; recompute its supplied randomness from the tampered signature so it cannot fail at the checksum stage.

## 6. Cross-relay disagreement tests

Both tests are mandatory and distinct.

**D1 — full workflow fault injection:** Relay A supplies the valid fixed historical beacon. Relay B supplies a different correctly encoded signature for the same round and pinned chain, with its randomness recomputed. Verify Relay B independently; an invalid alternative signature must fail at `BLS_VERIFICATION` before the agreement comparator. The injected workflow must abort.

**D2 — comparator unit test:** inject two clearly labelled fault-injected validation-result objects with the same round but differing signature bytes and derived seeds. The comparator must reject at `RELAY_AGREEMENT`. Do not claim that both injected objects are cryptographically valid signatures.

## 7. Pinned implementation and retained evidence

The v0.5 verifier must establish that:

- The package is exactly `drand-client@1.4.2`; the archived npm tarball matches the pinned registry SHA-1 and SHA-512 integrity values above.
- `package.json` and `package-lock.json` pin the same exact direct package versions as the v0.4 evidence, with the complete dependency tree and integrity metadata retained.
- Both relay instances are actual `HttpCachingChain` + `HttpChainClient` instances from that installed package, with beacon verification not disabled.
- Each `/info` response is compared with the pinned chain hash, public key, scheme, genesis time, period, and beacon ID before the fixed historical beacon is requested; the evidence output shows each expected value, actual value, and comparison result.
- The observed URLs use the legacy `/info` and `/public/1` paths for both origins; no v2 endpoint, transport adapter, or substituted package is used.
- The same fixed historical round was accepted by both clients, and round, decoded signature bytes, locally derived seed, and supplied v1 randomness (where present) agree.
- The nine original negative fixtures plus four added chain-metadata mutation fixtures, D1 and D2, pair-universe digest, n=28/n=27 rejection-boundary checks, fixed synthetic digest-index and pair-mapping vectors, and injected counter-increment checks pass.

Retain the v0.5 protocol, verifier script, `package.json`, `package-lock.json`, exact npm tarball, npm metadata, complete raw client requests/responses and structured verification output. Record SHA-256 for the protocol, script, package files, tarball, and evidence outputs. Keep the v0.4 protocol, verifier, results, and v2 adapter unchanged; identify that v2 adapter only as superseded historical evidence.

## 8. Stopped round and authorization boundary

Round `34323983` remains permanently excluded. Its retained request used a v2 path and its successful response omitted wire `randomness`; the initial failed response status/body were not retained. The then-locked preregistration required the field and the stop occurred before any rank or pair calculation. The v0.5 v1 client test does not retrieve or reuse this round.

This draft does not authorize any future beacon round, random draw, rank or pair mapping, pair selection, replacement allocation, parent-source construction, solver execution, candidate adoption, Rev11 amendment, or publication. Before a future attempt, Claude must issue explicit PASS on the exact final protocol and evidence, and the owner must separately authorize a newly preregistered attempt. A passing historical check or fixture suite is not draw authorization.
